L2 Voter File 2022 Elections Turnout Statistics for MS, aggregated to the 2020 Census Block level 

## Redistricting Data Hub (RDH) Retrieval Date
6/13/2023

## Sources
The Redistricting Data Hub purchased this Voter File from L2, a national Voter File vendor: https://l2-data.com/

## Fields
The fields below are from the L2 Voter File pulled by the RDH on 6/13/2023. 
L2 retrieved this voter file data from the state between April 3 and June 13 2023.
To see more detailed field descriptions, please view the attached data dictionary provided by L2. 
All fields are for individuals who are registered on the L2 Voter File as of the date of retrieval. The RDH did not have access to legacy or snapshot voter files. 
Field Name                                   		Description
geoid20                                      		15-character GEOID corresponding to 2020 Census Blocks, based on L2 geo-referencing of individual voter addresses
total_reg                                    		Count of total registered voters in the County, as geo-referenced by RDH from L2 voter file dated above
age_18_19                                    		Count of voters between the age of 18 and 19 in the Census Block
age_20_24                                    		Count of voters between the age of 20 and 24 in the Census Block
age_25_29                                    		Count of voters between the age of 25 and 29 in the Census Block
age_30_34                                    		Count of voters between the age of 30 and 34 in the Census Block
age_35_44                                    		Count of voters between the age of 35 and 44 in the Census Block
age_45_54                                    		Count of voters between the age of 45 and 54 in the Census Block
age_55_64                                    		Count of voters between the age of 55 and 64 in the Census Block
age_65_74                                    		Count of voters between the age of 65 and 74 in the Census Block
age_75_84                                    		Count of voters between the age of 75 and 84 in the Census Block
age_85over                                   		Count of voters over the age of 85 in the Census Block
voters_gender_m                              		Count of male voters
voters_gender_f                              		Count of female voters
voters_gender_unknown                        		Count of voters with unknown or other gender
party_npp                                    		Count of voters registered with the following party on the L2 Voter File: Non-Partisan *
party_rep                                    		Count of voters registered with the following party on the L2 Voter File: Republican *
party_dem                                    		Count of voters registered with the following party on the L2 Voter File: Democratic *
party_grn                                    		Count of voters registered with the following party on the L2 Voter File: Green *
party_oth                                    		Count of voters registered with another party, not listed above, on the L2 Voter File
party_unk                                    		Count of voters with unknown (null) party affiliation on the L2 Voter File
eth1_eur                                     		Count of voters in the following broad ethnicity category, defined by L2: European
eth1_hisp                                    		Count of voters in the following broad ethnicity category, defined by L2: Hispanic and Portuguese
eth1_aa                                      		Count of voters in the following broad ethnicity category, defined by L2: Likely African-American
eth1_esa                                     		Count of voters in the following broad ethnicity category, defined by L2: East and South Asian
eth1_oth                                     		Count of voters in the following broad ethnicity category, defined by L2: Other
eth1_unk                                     		Count of voters with unknown (null) broad ethnicity category
eth2_euro                                    		Count of voters in the following narrow ethnicity category, defined by L2: Summed European narrow ethnicities (see notes for what is included) **
eth2_93                                      		Count of voters in the following narrow ethnicity category, defined by L2: Likely Af-Am (Modeled) **
eth2_64                                      		Count of voters in the following narrow ethnicity category, defined by L2: Hispanic **
eth2_23                                      		Count of voters in the following narrow ethnicity category, defined by L2: Indian/Hindu **
eth2_30                                      		Count of voters in the following narrow ethnicity category, defined by L2: Arab **
eth2_10                                      		Count of voters in the following narrow ethnicity category, defined by L2: Chinese **
eth2_21                                      		Count of voters in the following narrow ethnicity category, defined by L2: Vietnamese **
eth2_99                                      		Count of voters in the following narrow ethnicity category, defined by L2: African or Af-Am Self Reported **
eth2_34                                      		Count of voters in the following narrow ethnicity category, defined by L2: Russian (omitting former Soviet States) **
eth2_14                                      		Count of voters in the following narrow ethnicity category, defined by L2: Korean **
eth2_unk                                     		Count of voters with unknown (null) narrow ethnicity category
languages_description_English                		Count of voters on the L2 Voter File known to speak the language: English
languages_description_Spanish                		Count of voters on the L2 Voter File known to speak the language: Spanish
languages_description_Vietnamese             		Count of voters on the L2 Voter File known to speak the language: Vietnamese
languages_description_Hindi                  		Count of voters on the L2 Voter File known to speak the language: Hindi
languages_description_Chinese                		Count of voters on the L2 Voter File known to speak the language: Chinese
languages_description_Arabic                 		Count of voters on the L2 Voter File known to speak the language: Arabic
commercialdata_estimatedhhincomeamount_avg   		Average of modeled data for estimated household income reported by L2 for individuals in the following ranges:  $1,000-$14,999/$15,000-$24,999/$25,000-$49,999/$50,000-$74,999/$75,000-$99,999/$100,000-$124,999/$125,000-$149,999/$150,000-$174,999/$175,000-$199,999/$200,000-$249,999/$250,000+
r20230131_voted_all                          		Count of voters who voted in the following election: runoff_2023_01_31
r20230131_reg_all                            		Count of voters registered on or before: 2023-01-31
r20230131_pct_voted_all                      		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31
r20230131_voted_gender_m                     		Count of voters who voted in the following election: runoff_2023_01_31, L2 Gender: Male
r20230131_reg_gender_m                       		Count of voters registered on or before: 2023-01-31, L2 Gender: Male
r20230131_pct_voted_gender_m                 		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Gender: Male
r20230131_voted_gender_f                     		Count of voters who voted in the following election: runoff_2023_01_31, L2 Gender: Female
r20230131_reg_gender_f                       		Count of voters registered on or before: 2023-01-31, L2 Gender: Female
r20230131_pct_voted_gender_f                 		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Gender: Female
r20230131_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2023_01_31, L2 Gender: Unknown
r20230131_reg_gender_unk                     		Count of voters registered on or before: 2023-01-31, L2 Gender: Unknown
r20230131_pct_voted_gender_unk               		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Gender: Unknown
r20230131_voted_eur                          		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: European
r20230131_reg_eur                            		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: European
r20230131_pct_voted_eur                      		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: European
r20230131_voted_hisp                         		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: Hispanic and Portuguese
r20230131_reg_hisp                           		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: Hispanic and Portuguese
r20230131_pct_voted_hisp                     		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: Hispanic and Portuguese
r20230131_voted_aa                           		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: Likely African-American
r20230131_reg_aa                             		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: Likely African-American
r20230131_pct_voted_aa                       		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: Likely African-American
r20230131_voted_esa                          		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: East and South Asian
r20230131_reg_esa                            		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: East and South Asian
r20230131_pct_voted_esa                      		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: East and South Asian
r20230131_voted_oth                          		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: Other
r20230131_reg_oth                            		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: Other
r20230131_pct_voted_oth                      		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: Other
r20230131_voted_unk                          		Count of voters who voted in the following election: runoff_2023_01_31, L2 Race or Ethnicity: Unknown
r20230131_reg_unk                            		Count of voters registered on or before: 2023-01-31, L2 Race or Ethnicity: Unknown
r20230131_pct_voted_unk                      		Percent of voters registered on or before 2023-01-31 and who voted in: runoff_2023_01_31, L2 Race or Ethnicity: Unknown
s20230110_voted_all                          		Count of voters who voted in the following election: special_2023_01_10
s20230110_reg_all                            		Count of voters registered on or before: 2023-01-10
s20230110_pct_voted_all                      		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10
s20230110_voted_gender_m                     		Count of voters who voted in the following election: special_2023_01_10, L2 Gender: Male
s20230110_reg_gender_m                       		Count of voters registered on or before: 2023-01-10, L2 Gender: Male
s20230110_pct_voted_gender_m                 		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Gender: Male
s20230110_voted_gender_f                     		Count of voters who voted in the following election: special_2023_01_10, L2 Gender: Female
s20230110_reg_gender_f                       		Count of voters registered on or before: 2023-01-10, L2 Gender: Female
s20230110_pct_voted_gender_f                 		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Gender: Female
s20230110_voted_gender_unk                   		Count of voters who voted in the following election: special_2023_01_10, L2 Gender: Unknown
s20230110_reg_gender_unk                     		Count of voters registered on or before: 2023-01-10, L2 Gender: Unknown
s20230110_pct_voted_gender_unk               		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Gender: Unknown
s20230110_voted_eur                          		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: European
s20230110_reg_eur                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: European
s20230110_pct_voted_eur                      		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: European
s20230110_voted_hisp                         		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: Hispanic and Portuguese
s20230110_reg_hisp                           		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Hispanic and Portuguese
s20230110_pct_voted_hisp                     		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: Hispanic and Portuguese
s20230110_voted_aa                           		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: Likely African-American
s20230110_reg_aa                             		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Likely African-American
s20230110_pct_voted_aa                       		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: Likely African-American
s20230110_voted_esa                          		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: East and South Asian
s20230110_reg_esa                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: East and South Asian
s20230110_pct_voted_esa                      		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: East and South Asian
s20230110_voted_oth                          		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: Other
s20230110_reg_oth                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Other
s20230110_pct_voted_oth                      		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: Other
s20230110_voted_unk                          		Count of voters who voted in the following election: special_2023_01_10, L2 Race or Ethnicity: Unknown
s20230110_reg_unk                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Unknown
s20230110_pct_voted_unk                      		Percent of voters registered on or before 2023-01-10 and who voted in: special_2023_01_10, L2 Race or Ethnicity: Unknown
r20230110_voted_all                          		Count of voters who voted in the following election: runoff_2023_01_10
r20230110_reg_all                            		Count of voters registered on or before: 2023-01-10
r20230110_pct_voted_all                      		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10
r20230110_voted_gender_m                     		Count of voters who voted in the following election: runoff_2023_01_10, L2 Gender: Male
r20230110_reg_gender_m                       		Count of voters registered on or before: 2023-01-10, L2 Gender: Male
r20230110_pct_voted_gender_m                 		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Gender: Male
r20230110_voted_gender_f                     		Count of voters who voted in the following election: runoff_2023_01_10, L2 Gender: Female
r20230110_reg_gender_f                       		Count of voters registered on or before: 2023-01-10, L2 Gender: Female
r20230110_pct_voted_gender_f                 		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Gender: Female
r20230110_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2023_01_10, L2 Gender: Unknown
r20230110_reg_gender_unk                     		Count of voters registered on or before: 2023-01-10, L2 Gender: Unknown
r20230110_pct_voted_gender_unk               		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Gender: Unknown
r20230110_voted_eur                          		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: European
r20230110_reg_eur                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: European
r20230110_pct_voted_eur                      		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: European
r20230110_voted_hisp                         		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: Hispanic and Portuguese
r20230110_reg_hisp                           		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Hispanic and Portuguese
r20230110_pct_voted_hisp                     		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: Hispanic and Portuguese
r20230110_voted_aa                           		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: Likely African-American
r20230110_reg_aa                             		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Likely African-American
r20230110_pct_voted_aa                       		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: Likely African-American
r20230110_voted_esa                          		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: East and South Asian
r20230110_reg_esa                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: East and South Asian
r20230110_pct_voted_esa                      		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: East and South Asian
r20230110_voted_oth                          		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: Other
r20230110_reg_oth                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Other
r20230110_pct_voted_oth                      		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: Other
r20230110_voted_unk                          		Count of voters who voted in the following election: runoff_2023_01_10, L2 Race or Ethnicity: Unknown
r20230110_reg_unk                            		Count of voters registered on or before: 2023-01-10, L2 Race or Ethnicity: Unknown
r20230110_pct_voted_unk                      		Percent of voters registered on or before 2023-01-10 and who voted in: runoff_2023_01_10, L2 Race or Ethnicity: Unknown
r20221129_voted_all                          		Count of voters who voted in the following election: runoff_2022_11_29
r20221129_reg_all                            		Count of voters registered on or before: 2022-11-29
r20221129_pct_voted_all                      		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29
r20221129_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_11_29, L2 Gender: Male
r20221129_reg_gender_m                       		Count of voters registered on or before: 2022-11-29, L2 Gender: Male
r20221129_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Gender: Male
r20221129_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_11_29, L2 Gender: Female
r20221129_reg_gender_f                       		Count of voters registered on or before: 2022-11-29, L2 Gender: Female
r20221129_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Gender: Female
r20221129_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_11_29, L2 Gender: Unknown
r20221129_reg_gender_unk                     		Count of voters registered on or before: 2022-11-29, L2 Gender: Unknown
r20221129_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Gender: Unknown
r20221129_voted_eur                          		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: European
r20221129_reg_eur                            		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: European
r20221129_pct_voted_eur                      		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: European
r20221129_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: Hispanic and Portuguese
r20221129_reg_hisp                           		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: Hispanic and Portuguese
r20221129_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: Hispanic and Portuguese
r20221129_voted_aa                           		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: Likely African-American
r20221129_reg_aa                             		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: Likely African-American
r20221129_pct_voted_aa                       		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: Likely African-American
r20221129_voted_esa                          		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: East and South Asian
r20221129_reg_esa                            		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: East and South Asian
r20221129_pct_voted_esa                      		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: East and South Asian
r20221129_voted_oth                          		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: Other
r20221129_reg_oth                            		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: Other
r20221129_pct_voted_oth                      		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: Other
r20221129_voted_unk                          		Count of voters who voted in the following election: runoff_2022_11_29, L2 Race or Ethnicity: Unknown
r20221129_reg_unk                            		Count of voters registered on or before: 2022-11-29, L2 Race or Ethnicity: Unknown
r20221129_pct_voted_unk                      		Percent of voters registered on or before 2022-11-29 and who voted in: runoff_2022_11_29, L2 Race or Ethnicity: Unknown
s20221108_voted_all                          		Count of voters who voted in the following election: special_2022_11_08
s20221108_reg_all                            		Count of voters registered on or before: 2022-11-08
s20221108_pct_voted_all                      		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08
s20221108_voted_gender_m                     		Count of voters who voted in the following election: special_2022_11_08, L2 Gender: Male
s20221108_reg_gender_m                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Male
s20221108_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Gender: Male
s20221108_voted_gender_f                     		Count of voters who voted in the following election: special_2022_11_08, L2 Gender: Female
s20221108_reg_gender_f                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Female
s20221108_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Gender: Female
s20221108_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_11_08, L2 Gender: Unknown
s20221108_reg_gender_unk                     		Count of voters registered on or before: 2022-11-08, L2 Gender: Unknown
s20221108_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Gender: Unknown
s20221108_voted_eur                          		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: European
s20221108_reg_eur                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: European
s20221108_pct_voted_eur                      		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: European
s20221108_voted_hisp                         		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
s20221108_reg_hisp                           		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Hispanic and Portuguese
s20221108_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
s20221108_voted_aa                           		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: Likely African-American
s20221108_reg_aa                             		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Likely African-American
s20221108_pct_voted_aa                       		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: Likely African-American
s20221108_voted_esa                          		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: East and South Asian
s20221108_reg_esa                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: East and South Asian
s20221108_pct_voted_esa                      		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: East and South Asian
s20221108_voted_oth                          		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: Other
s20221108_reg_oth                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Other
s20221108_pct_voted_oth                      		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: Other
s20221108_voted_unk                          		Count of voters who voted in the following election: special_2022_11_08, L2 Race or Ethnicity: Unknown
s20221108_reg_unk                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Unknown
s20221108_pct_voted_unk                      		Percent of voters registered on or before 2022-11-08 and who voted in: special_2022_11_08, L2 Race or Ethnicity: Unknown
r20221108_voted_all                          		Count of voters who voted in the following election: runoff_2022_11_08
r20221108_reg_all                            		Count of voters registered on or before: 2022-11-08
r20221108_pct_voted_all                      		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08
r20221108_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_11_08, L2 Gender: Male
r20221108_reg_gender_m                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Male
r20221108_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Gender: Male
r20221108_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_11_08, L2 Gender: Female
r20221108_reg_gender_f                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Female
r20221108_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Gender: Female
r20221108_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_11_08, L2 Gender: Unknown
r20221108_reg_gender_unk                     		Count of voters registered on or before: 2022-11-08, L2 Gender: Unknown
r20221108_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Gender: Unknown
r20221108_voted_eur                          		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: European
r20221108_reg_eur                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: European
r20221108_pct_voted_eur                      		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: European
r20221108_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
r20221108_reg_hisp                           		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Hispanic and Portuguese
r20221108_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
r20221108_voted_aa                           		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: Likely African-American
r20221108_reg_aa                             		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Likely African-American
r20221108_pct_voted_aa                       		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: Likely African-American
r20221108_voted_esa                          		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: East and South Asian
r20221108_reg_esa                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: East and South Asian
r20221108_pct_voted_esa                      		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: East and South Asian
r20221108_voted_oth                          		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: Other
r20221108_reg_oth                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Other
r20221108_pct_voted_oth                      		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: Other
r20221108_voted_unk                          		Count of voters who voted in the following election: runoff_2022_11_08, L2 Race or Ethnicity: Unknown
r20221108_reg_unk                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Unknown
r20221108_pct_voted_unk                      		Percent of voters registered on or before 2022-11-08 and who voted in: runoff_2022_11_08, L2 Race or Ethnicity: Unknown
g20221108_voted_all                          		Count of voters who voted in the following election: general_2022_11_08
g20221108_reg_all                            		Count of voters registered on or before: 2022-11-08
g20221108_pct_voted_all                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08
g20221108_voted_gender_m                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Male
g20221108_reg_gender_m                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Male
g20221108_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Male
g20221108_voted_gender_f                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Female
g20221108_reg_gender_f                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Female
g20221108_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Female
g20221108_voted_gender_unk                   		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Unknown
g20221108_reg_gender_unk                     		Count of voters registered on or before: 2022-11-08, L2 Gender: Unknown
g20221108_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Unknown
g20221108_voted_eur                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_reg_eur                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: European
g20221108_pct_voted_eur                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_voted_hisp                         		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_reg_hisp                           		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_voted_aa                           		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_reg_aa                             		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Likely African-American
g20221108_pct_voted_aa                       		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_voted_esa                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_reg_esa                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: East and South Asian
g20221108_pct_voted_esa                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_voted_oth                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_reg_oth                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Other
g20221108_pct_voted_oth                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_voted_unk                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Unknown
g20221108_reg_unk                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Unknown
g20221108_pct_voted_unk                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Unknown
r20221025_voted_all                          		Count of voters who voted in the following election: runoff_2022_10_25
r20221025_reg_all                            		Count of voters registered on or before: 2022-10-25
r20221025_pct_voted_all                      		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25
r20221025_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_10_25, L2 Gender: Male
r20221025_reg_gender_m                       		Count of voters registered on or before: 2022-10-25, L2 Gender: Male
r20221025_pct_voted_gender_m                 		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Gender: Male
r20221025_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_10_25, L2 Gender: Female
r20221025_reg_gender_f                       		Count of voters registered on or before: 2022-10-25, L2 Gender: Female
r20221025_pct_voted_gender_f                 		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Gender: Female
r20221025_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_10_25, L2 Gender: Unknown
r20221025_reg_gender_unk                     		Count of voters registered on or before: 2022-10-25, L2 Gender: Unknown
r20221025_pct_voted_gender_unk               		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Gender: Unknown
r20221025_voted_eur                          		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: European
r20221025_reg_eur                            		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: European
r20221025_pct_voted_eur                      		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: European
r20221025_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: Hispanic and Portuguese
r20221025_reg_hisp                           		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: Hispanic and Portuguese
r20221025_pct_voted_hisp                     		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: Hispanic and Portuguese
r20221025_voted_aa                           		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: Likely African-American
r20221025_reg_aa                             		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: Likely African-American
r20221025_pct_voted_aa                       		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: Likely African-American
r20221025_voted_esa                          		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: East and South Asian
r20221025_reg_esa                            		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: East and South Asian
r20221025_pct_voted_esa                      		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: East and South Asian
r20221025_voted_oth                          		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: Other
r20221025_reg_oth                            		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: Other
r20221025_pct_voted_oth                      		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: Other
r20221025_voted_unk                          		Count of voters who voted in the following election: runoff_2022_10_25, L2 Race or Ethnicity: Unknown
r20221025_reg_unk                            		Count of voters registered on or before: 2022-10-25, L2 Race or Ethnicity: Unknown
r20221025_pct_voted_unk                      		Percent of voters registered on or before 2022-10-25 and who voted in: runoff_2022_10_25, L2 Race or Ethnicity: Unknown
s20220913_voted_all                          		Count of voters who voted in the following election: special_2022_09_13
s20220913_reg_all                            		Count of voters registered on or before: 2022-09-13
s20220913_pct_voted_all                      		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13
s20220913_voted_gender_m                     		Count of voters who voted in the following election: special_2022_09_13, L2 Gender: Male
s20220913_reg_gender_m                       		Count of voters registered on or before: 2022-09-13, L2 Gender: Male
s20220913_pct_voted_gender_m                 		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Gender: Male
s20220913_voted_gender_f                     		Count of voters who voted in the following election: special_2022_09_13, L2 Gender: Female
s20220913_reg_gender_f                       		Count of voters registered on or before: 2022-09-13, L2 Gender: Female
s20220913_pct_voted_gender_f                 		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Gender: Female
s20220913_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_09_13, L2 Gender: Unknown
s20220913_reg_gender_unk                     		Count of voters registered on or before: 2022-09-13, L2 Gender: Unknown
s20220913_pct_voted_gender_unk               		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Gender: Unknown
s20220913_voted_eur                          		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: European
s20220913_reg_eur                            		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: European
s20220913_pct_voted_eur                      		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: European
s20220913_voted_hisp                         		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: Hispanic and Portuguese
s20220913_reg_hisp                           		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: Hispanic and Portuguese
s20220913_pct_voted_hisp                     		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: Hispanic and Portuguese
s20220913_voted_aa                           		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: Likely African-American
s20220913_reg_aa                             		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: Likely African-American
s20220913_pct_voted_aa                       		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: Likely African-American
s20220913_voted_esa                          		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: East and South Asian
s20220913_reg_esa                            		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: East and South Asian
s20220913_pct_voted_esa                      		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: East and South Asian
s20220913_voted_oth                          		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: Other
s20220913_reg_oth                            		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: Other
s20220913_pct_voted_oth                      		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: Other
s20220913_voted_unk                          		Count of voters who voted in the following election: special_2022_09_13, L2 Race or Ethnicity: Unknown
s20220913_reg_unk                            		Count of voters registered on or before: 2022-09-13, L2 Race or Ethnicity: Unknown
s20220913_pct_voted_unk                      		Percent of voters registered on or before 2022-09-13 and who voted in: special_2022_09_13, L2 Race or Ethnicity: Unknown
r20220823_voted_all                          		Count of voters who voted in the following election: runoff_2022_08_23
r20220823_reg_all                            		Count of voters registered on or before: 2022-08-23
r20220823_pct_voted_all                      		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23
r20220823_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_08_23, L2 Gender: Male
r20220823_reg_gender_m                       		Count of voters registered on or before: 2022-08-23, L2 Gender: Male
r20220823_pct_voted_gender_m                 		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Gender: Male
r20220823_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_08_23, L2 Gender: Female
r20220823_reg_gender_f                       		Count of voters registered on or before: 2022-08-23, L2 Gender: Female
r20220823_pct_voted_gender_f                 		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Gender: Female
r20220823_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_08_23, L2 Gender: Unknown
r20220823_reg_gender_unk                     		Count of voters registered on or before: 2022-08-23, L2 Gender: Unknown
r20220823_pct_voted_gender_unk               		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Gender: Unknown
r20220823_voted_eur                          		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: European
r20220823_reg_eur                            		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: European
r20220823_pct_voted_eur                      		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: European
r20220823_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: Hispanic and Portuguese
r20220823_reg_hisp                           		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: Hispanic and Portuguese
r20220823_pct_voted_hisp                     		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: Hispanic and Portuguese
r20220823_voted_aa                           		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: Likely African-American
r20220823_reg_aa                             		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: Likely African-American
r20220823_pct_voted_aa                       		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: Likely African-American
r20220823_voted_esa                          		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: East and South Asian
r20220823_reg_esa                            		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: East and South Asian
r20220823_pct_voted_esa                      		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: East and South Asian
r20220823_voted_oth                          		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: Other
r20220823_reg_oth                            		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: Other
r20220823_pct_voted_oth                      		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: Other
r20220823_voted_unk                          		Count of voters who voted in the following election: runoff_2022_08_23, L2 Race or Ethnicity: Unknown
r20220823_reg_unk                            		Count of voters registered on or before: 2022-08-23, L2 Race or Ethnicity: Unknown
r20220823_pct_voted_unk                      		Percent of voters registered on or before 2022-08-23 and who voted in: runoff_2022_08_23, L2 Race or Ethnicity: Unknown
s20220802_voted_all                          		Count of voters who voted in the following election: special_2022_08_02
s20220802_reg_all                            		Count of voters registered on or before: 2022-08-02
s20220802_pct_voted_all                      		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02
s20220802_voted_gender_m                     		Count of voters who voted in the following election: special_2022_08_02, L2 Gender: Male
s20220802_reg_gender_m                       		Count of voters registered on or before: 2022-08-02, L2 Gender: Male
s20220802_pct_voted_gender_m                 		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Gender: Male
s20220802_voted_gender_f                     		Count of voters who voted in the following election: special_2022_08_02, L2 Gender: Female
s20220802_reg_gender_f                       		Count of voters registered on or before: 2022-08-02, L2 Gender: Female
s20220802_pct_voted_gender_f                 		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Gender: Female
s20220802_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_08_02, L2 Gender: Unknown
s20220802_reg_gender_unk                     		Count of voters registered on or before: 2022-08-02, L2 Gender: Unknown
s20220802_pct_voted_gender_unk               		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Gender: Unknown
s20220802_voted_eur                          		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: European
s20220802_reg_eur                            		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: European
s20220802_pct_voted_eur                      		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: European
s20220802_voted_hisp                         		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20220802_reg_hisp                           		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: Hispanic and Portuguese
s20220802_pct_voted_hisp                     		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: Hispanic and Portuguese
s20220802_voted_aa                           		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: Likely African-American
s20220802_reg_aa                             		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: Likely African-American
s20220802_pct_voted_aa                       		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: Likely African-American
s20220802_voted_esa                          		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: East and South Asian
s20220802_reg_esa                            		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: East and South Asian
s20220802_pct_voted_esa                      		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: East and South Asian
s20220802_voted_oth                          		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: Other
s20220802_reg_oth                            		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: Other
s20220802_pct_voted_oth                      		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: Other
s20220802_voted_unk                          		Count of voters who voted in the following election: special_2022_08_02, L2 Race or Ethnicity: Unknown
s20220802_reg_unk                            		Count of voters registered on or before: 2022-08-02, L2 Race or Ethnicity: Unknown
s20220802_pct_voted_unk                      		Percent of voters registered on or before 2022-08-02 and who voted in: special_2022_08_02, L2 Race or Ethnicity: Unknown
s20220719_voted_all                          		Count of voters who voted in the following election: special_2022_07_19
s20220719_reg_all                            		Count of voters registered on or before: 2022-07-19
s20220719_pct_voted_all                      		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19
s20220719_voted_gender_m                     		Count of voters who voted in the following election: special_2022_07_19, L2 Gender: Male
s20220719_reg_gender_m                       		Count of voters registered on or before: 2022-07-19, L2 Gender: Male
s20220719_pct_voted_gender_m                 		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Gender: Male
s20220719_voted_gender_f                     		Count of voters who voted in the following election: special_2022_07_19, L2 Gender: Female
s20220719_reg_gender_f                       		Count of voters registered on or before: 2022-07-19, L2 Gender: Female
s20220719_pct_voted_gender_f                 		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Gender: Female
s20220719_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_07_19, L2 Gender: Unknown
s20220719_reg_gender_unk                     		Count of voters registered on or before: 2022-07-19, L2 Gender: Unknown
s20220719_pct_voted_gender_unk               		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Gender: Unknown
s20220719_voted_eur                          		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: European
s20220719_reg_eur                            		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: European
s20220719_pct_voted_eur                      		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: European
s20220719_voted_hisp                         		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: Hispanic and Portuguese
s20220719_reg_hisp                           		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: Hispanic and Portuguese
s20220719_pct_voted_hisp                     		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: Hispanic and Portuguese
s20220719_voted_aa                           		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: Likely African-American
s20220719_reg_aa                             		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: Likely African-American
s20220719_pct_voted_aa                       		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: Likely African-American
s20220719_voted_esa                          		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: East and South Asian
s20220719_reg_esa                            		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: East and South Asian
s20220719_pct_voted_esa                      		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: East and South Asian
s20220719_voted_oth                          		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: Other
s20220719_reg_oth                            		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: Other
s20220719_pct_voted_oth                      		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: Other
s20220719_voted_unk                          		Count of voters who voted in the following election: special_2022_07_19, L2 Race or Ethnicity: Unknown
s20220719_reg_unk                            		Count of voters registered on or before: 2022-07-19, L2 Race or Ethnicity: Unknown
s20220719_pct_voted_unk                      		Percent of voters registered on or before 2022-07-19 and who voted in: special_2022_07_19, L2 Race or Ethnicity: Unknown
p20220607_voted_all                          		Count of voters who voted in the following election: primary_2022_06_07
p20220607_reg_all                            		Count of voters registered on or before: 2022-06-07
p20220607_pct_voted_all                      		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07
p20220607_voted_gender_m                     		Count of voters who voted in the following election: primary_2022_06_07, L2 Gender: Male
p20220607_reg_gender_m                       		Count of voters registered on or before: 2022-06-07, L2 Gender: Male
p20220607_pct_voted_gender_m                 		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Gender: Male
p20220607_voted_gender_f                     		Count of voters who voted in the following election: primary_2022_06_07, L2 Gender: Female
p20220607_reg_gender_f                       		Count of voters registered on or before: 2022-06-07, L2 Gender: Female
p20220607_pct_voted_gender_f                 		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Gender: Female
p20220607_voted_gender_unk                   		Count of voters who voted in the following election: primary_2022_06_07, L2 Gender: Unknown
p20220607_reg_gender_unk                     		Count of voters registered on or before: 2022-06-07, L2 Gender: Unknown
p20220607_pct_voted_gender_unk               		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Gender: Unknown
p20220607_voted_eur                          		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: European
p20220607_reg_eur                            		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: European
p20220607_pct_voted_eur                      		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: European
p20220607_voted_hisp                         		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: Hispanic and Portuguese
p20220607_reg_hisp                           		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: Hispanic and Portuguese
p20220607_pct_voted_hisp                     		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: Hispanic and Portuguese
p20220607_voted_aa                           		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: Likely African-American
p20220607_reg_aa                             		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: Likely African-American
p20220607_pct_voted_aa                       		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: Likely African-American
p20220607_voted_esa                          		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: East and South Asian
p20220607_reg_esa                            		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: East and South Asian
p20220607_pct_voted_esa                      		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: East and South Asian
p20220607_voted_oth                          		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: Other
p20220607_reg_oth                            		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: Other
p20220607_pct_voted_oth                      		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: Other
p20220607_voted_unk                          		Count of voters who voted in the following election: primary_2022_06_07, L2 Race or Ethnicity: Unknown
p20220607_reg_unk                            		Count of voters registered on or before: 2022-06-07, L2 Race or Ethnicity: Unknown
p20220607_pct_voted_unk                      		Percent of voters registered on or before 2022-06-07 and who voted in: primary_2022_06_07, L2 Race or Ethnicity: Unknown
s20220517_voted_all                          		Count of voters who voted in the following election: special_2022_05_17
s20220517_reg_all                            		Count of voters registered on or before: 2022-05-17
s20220517_pct_voted_all                      		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17
s20220517_voted_gender_m                     		Count of voters who voted in the following election: special_2022_05_17, L2 Gender: Male
s20220517_reg_gender_m                       		Count of voters registered on or before: 2022-05-17, L2 Gender: Male
s20220517_pct_voted_gender_m                 		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Gender: Male
s20220517_voted_gender_f                     		Count of voters who voted in the following election: special_2022_05_17, L2 Gender: Female
s20220517_reg_gender_f                       		Count of voters registered on or before: 2022-05-17, L2 Gender: Female
s20220517_pct_voted_gender_f                 		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Gender: Female
s20220517_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_05_17, L2 Gender: Unknown
s20220517_reg_gender_unk                     		Count of voters registered on or before: 2022-05-17, L2 Gender: Unknown
s20220517_pct_voted_gender_unk               		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Gender: Unknown
s20220517_voted_eur                          		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: European
s20220517_reg_eur                            		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: European
s20220517_pct_voted_eur                      		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: European
s20220517_voted_hisp                         		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: Hispanic and Portuguese
s20220517_reg_hisp                           		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: Hispanic and Portuguese
s20220517_pct_voted_hisp                     		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: Hispanic and Portuguese
s20220517_voted_aa                           		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: Likely African-American
s20220517_reg_aa                             		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: Likely African-American
s20220517_pct_voted_aa                       		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: Likely African-American
s20220517_voted_esa                          		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: East and South Asian
s20220517_reg_esa                            		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: East and South Asian
s20220517_pct_voted_esa                      		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: East and South Asian
s20220517_voted_oth                          		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: Other
s20220517_reg_oth                            		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: Other
s20220517_pct_voted_oth                      		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: Other
s20220517_voted_unk                          		Count of voters who voted in the following election: special_2022_05_17, L2 Race or Ethnicity: Unknown
s20220517_reg_unk                            		Count of voters registered on or before: 2022-05-17, L2 Race or Ethnicity: Unknown
s20220517_pct_voted_unk                      		Percent of voters registered on or before 2022-05-17 and who voted in: special_2022_05_17, L2 Race or Ethnicity: Unknown
cg20211102_voted_all                         		Count of voters who voted in the following election: consolidated_general_2021_11_02
cg20211102_reg_all                           		Count of voters registered on or before: 2021-11-02
cg20211102_pct_voted_all                     		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02
cg20211102_voted_gender_m                    		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Gender: Male
cg20211102_reg_gender_m                      		Count of voters registered on or before: 2021-11-02, L2 Gender: Male
cg20211102_pct_voted_gender_m                		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Gender: Male
cg20211102_voted_gender_f                    		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Gender: Female
cg20211102_reg_gender_f                      		Count of voters registered on or before: 2021-11-02, L2 Gender: Female
cg20211102_pct_voted_gender_f                		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Gender: Female
cg20211102_voted_gender_unk                  		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Gender: Unknown
cg20211102_reg_gender_unk                    		Count of voters registered on or before: 2021-11-02, L2 Gender: Unknown
cg20211102_pct_voted_gender_unk              		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Gender: Unknown
cg20211102_voted_eur                         		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: European
cg20211102_reg_eur                           		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: European
cg20211102_pct_voted_eur                     		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: European
cg20211102_voted_hisp                        		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: Hispanic and Portuguese
cg20211102_reg_hisp                          		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Hispanic and Portuguese
cg20211102_pct_voted_hisp                    		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: Hispanic and Portuguese
cg20211102_voted_aa                          		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: Likely African-American
cg20211102_reg_aa                            		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Likely African-American
cg20211102_pct_voted_aa                      		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: Likely African-American
cg20211102_voted_esa                         		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: East and South Asian
cg20211102_reg_esa                           		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: East and South Asian
cg20211102_pct_voted_esa                     		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: East and South Asian
cg20211102_voted_oth                         		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: Other
cg20211102_reg_oth                           		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Other
cg20211102_pct_voted_oth                     		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: Other
cg20211102_voted_unk                         		Count of voters who voted in the following election: consolidated_general_2021_11_02, L2 Race or Ethnicity: Unknown
cg20211102_reg_unk                           		Count of voters registered on or before: 2021-11-02, L2 Race or Ethnicity: Unknown
cg20211102_pct_voted_unk                     		Percent of voters registered on or before 2021-11-02 and who voted in: consolidated_general_2021_11_02, L2 Race or Ethnicity: Unknown
cp20210608_voted_all                         		Count of voters who voted in the following election: consolidated_primary_2021_06_08
cp20210608_reg_all                           		Count of voters registered on or before: 2021-06-08
cp20210608_pct_voted_all                     		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08
cp20210608_voted_gender_m                    		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Gender: Male
cp20210608_reg_gender_m                      		Count of voters registered on or before: 2021-06-08, L2 Gender: Male
cp20210608_pct_voted_gender_m                		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Gender: Male
cp20210608_voted_gender_f                    		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Gender: Female
cp20210608_reg_gender_f                      		Count of voters registered on or before: 2021-06-08, L2 Gender: Female
cp20210608_pct_voted_gender_f                		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Gender: Female
cp20210608_voted_gender_unk                  		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Gender: Unknown
cp20210608_reg_gender_unk                    		Count of voters registered on or before: 2021-06-08, L2 Gender: Unknown
cp20210608_pct_voted_gender_unk              		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Gender: Unknown
cp20210608_voted_eur                         		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: European
cp20210608_reg_eur                           		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: European
cp20210608_pct_voted_eur                     		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: European
cp20210608_voted_hisp                        		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Hispanic and Portuguese
cp20210608_reg_hisp                          		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: Hispanic and Portuguese
cp20210608_pct_voted_hisp                    		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Hispanic and Portuguese
cp20210608_voted_aa                          		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Likely African-American
cp20210608_reg_aa                            		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: Likely African-American
cp20210608_pct_voted_aa                      		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Likely African-American
cp20210608_voted_esa                         		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: East and South Asian
cp20210608_reg_esa                           		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: East and South Asian
cp20210608_pct_voted_esa                     		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: East and South Asian
cp20210608_voted_oth                         		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Other
cp20210608_reg_oth                           		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: Other
cp20210608_pct_voted_oth                     		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Other
cp20210608_voted_unk                         		Count of voters who voted in the following election: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Unknown
cp20210608_reg_unk                           		Count of voters registered on or before: 2021-06-08, L2 Race or Ethnicity: Unknown
cp20210608_pct_voted_unk                     		Percent of voters registered on or before 2021-06-08 and who voted in: consolidated_primary_2021_06_08, L2 Race or Ethnicity: Unknown
g20201103_voted_all                          		Count of voters who voted in the following election: general_2020_11_03
g20201103_reg_all                            		Count of voters registered on or before: 2020-11-03
g20201103_pct_voted_all                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03
g20201103_voted_gender_m                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Male
g20201103_reg_gender_m                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Male
g20201103_pct_voted_gender_m                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Male
g20201103_voted_gender_f                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Female
g20201103_reg_gender_f                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Female
g20201103_pct_voted_gender_f                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Female
g20201103_voted_gender_unk                   		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Unknown
g20201103_reg_gender_unk                     		Count of voters registered on or before: 2020-11-03, L2 Gender: Unknown
g20201103_pct_voted_gender_unk               		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Unknown
g20201103_voted_eur                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_reg_eur                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: European
g20201103_pct_voted_eur                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_voted_hisp                         		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_reg_hisp                           		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_pct_voted_hisp                     		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_voted_aa                           		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_reg_aa                             		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Likely African-American
g20201103_pct_voted_aa                       		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_voted_esa                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_reg_esa                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: East and South Asian
g20201103_pct_voted_esa                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_voted_oth                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_reg_oth                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Other
g20201103_pct_voted_oth                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_voted_unk                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Unknown
g20201103_reg_unk                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Unknown
g20201103_pct_voted_unk                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Unknown
pp20200310_voted_all                         		Count of voters who voted in the following election: presidential_primary_2020_03_10
pp20200310_reg_all                           		Count of voters registered on or before: 2020-03-10
pp20200310_pct_voted_all                     		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10
pp20200310_voted_gender_m                    		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Gender: Male
pp20200310_reg_gender_m                      		Count of voters registered on or before: 2020-03-10, L2 Gender: Male
pp20200310_pct_voted_gender_m                		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Gender: Male
pp20200310_voted_gender_f                    		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Gender: Female
pp20200310_reg_gender_f                      		Count of voters registered on or before: 2020-03-10, L2 Gender: Female
pp20200310_pct_voted_gender_f                		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Gender: Female
pp20200310_voted_gender_unk                  		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Gender: Unknown
pp20200310_reg_gender_unk                    		Count of voters registered on or before: 2020-03-10, L2 Gender: Unknown
pp20200310_pct_voted_gender_unk              		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Gender: Unknown
pp20200310_voted_eur                         		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: European
pp20200310_reg_eur                           		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: European
pp20200310_pct_voted_eur                     		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: European
pp20200310_voted_hisp                        		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200310_reg_hisp                          		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200310_pct_voted_hisp                    		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200310_voted_aa                          		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: Likely African-American
pp20200310_reg_aa                            		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Likely African-American
pp20200310_pct_voted_aa                      		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: Likely African-American
pp20200310_voted_esa                         		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: East and South Asian
pp20200310_reg_esa                           		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: East and South Asian
pp20200310_pct_voted_esa                     		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: East and South Asian
pp20200310_voted_oth                         		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: Other
pp20200310_reg_oth                           		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Other
pp20200310_pct_voted_oth                     		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: Other
pp20200310_voted_unk                         		Count of voters who voted in the following election: presidential_primary_2020_03_10, L2 Race or Ethnicity: Unknown
pp20200310_reg_unk                           		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Unknown
pp20200310_pct_voted_unk                     		Percent of voters registered on or before 2020-03-10 and who voted in: presidential_primary_2020_03_10, L2 Race or Ethnicity: Unknown
p20200310_voted_all                          		Count of voters who voted in the following election: primary_2020_03_10
p20200310_reg_all                            		Count of voters registered on or before: 2020-03-10
p20200310_pct_voted_all                      		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10
p20200310_voted_gender_m                     		Count of voters who voted in the following election: primary_2020_03_10, L2 Gender: Male
p20200310_reg_gender_m                       		Count of voters registered on or before: 2020-03-10, L2 Gender: Male
p20200310_pct_voted_gender_m                 		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Gender: Male
p20200310_voted_gender_f                     		Count of voters who voted in the following election: primary_2020_03_10, L2 Gender: Female
p20200310_reg_gender_f                       		Count of voters registered on or before: 2020-03-10, L2 Gender: Female
p20200310_pct_voted_gender_f                 		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Gender: Female
p20200310_voted_gender_unk                   		Count of voters who voted in the following election: primary_2020_03_10, L2 Gender: Unknown
p20200310_reg_gender_unk                     		Count of voters registered on or before: 2020-03-10, L2 Gender: Unknown
p20200310_pct_voted_gender_unk               		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Gender: Unknown
p20200310_voted_eur                          		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: European
p20200310_reg_eur                            		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: European
p20200310_pct_voted_eur                      		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: European
p20200310_voted_hisp                         		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: Hispanic and Portuguese
p20200310_reg_hisp                           		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Hispanic and Portuguese
p20200310_pct_voted_hisp                     		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: Hispanic and Portuguese
p20200310_voted_aa                           		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: Likely African-American
p20200310_reg_aa                             		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Likely African-American
p20200310_pct_voted_aa                       		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: Likely African-American
p20200310_voted_esa                          		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: East and South Asian
p20200310_reg_esa                            		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: East and South Asian
p20200310_pct_voted_esa                      		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: East and South Asian
p20200310_voted_oth                          		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: Other
p20200310_reg_oth                            		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Other
p20200310_pct_voted_oth                      		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: Other
p20200310_voted_unk                          		Count of voters who voted in the following election: primary_2020_03_10, L2 Race or Ethnicity: Unknown
p20200310_reg_unk                            		Count of voters registered on or before: 2020-03-10, L2 Race or Ethnicity: Unknown
p20200310_pct_voted_unk                      		Percent of voters registered on or before 2020-03-10 and who voted in: primary_2020_03_10, L2 Race or Ethnicity: Unknown

## Processing 
L2 provides individual address data for every voter on their voter file. 
Many of the voters contain latitude/longitude data. The RDH assigns 2020 Census blocks to voters containing latitude/longitude data by spatially joining the points with Census block files. 
Voters that are assigned to a block in a county that does not match their county on the voter file are removed as a quality control check. 
The individual data is aggregated to the block-level by grouping by block assignments. Individuals who could not be assigned a Census block because of missing latitude/longitude were assigned “NO ASSIGNMENT - [county fips code assignment]" and therefore reported as county aggregates in the geoid20 column.

## Additional Notes 
The fields in this file correspond to those voters registered to vote at their residence as of the date mentioned above. 
The vote history fields are tied to individual voters, then aggregated up - not tied to blocks as a whole, and as such represent whether or not voters in the block as of the L2 voter file date above voted *anywhere*, not necessarily specifically in that block. 
As such, this information can be used to approximate how the demographic in the block voted historically, but cannot be used to track how individuals in that block voted at the time of previous elections. For snapshots from previous voter files, please reference previous voter files hosted by the RDH. 

The RDH cannot certify the accuracy of any of the information contained within this file.

* RDH is providing aggregates of the top 8 parties in the state. 
** For the narrow ethnicity categories, RDH is providing an aggregate of all ethnicities that have more than 
1000 individuals state-wide. L2 ethnicity categories use modeling techniques to infer an individual's ethnicity.
Please see the attached PDF for  more information about L2's ethnicity fields. 


Please contact info@redistrictingdatahub.org for more information. 