Florida 2022 Primary Election Precinct-Level Results and Boundaries

## RDH Date Retrieval
01/20/2024

## Sources
Elections results from [Florida Division of Elections](https://dos.myflorida.com/elections/data-statistics/elections-data/precinct-level-election-results/)

Precinct shapefiles for the following counties sourced from the respective county Supervisor of Elections: Alachua, Charlotte, Glades, Hillsborough, Palm Beach, Brevard, Citrus, Clay, Collier, Dade, Flagler, Lee, Marion, Nassau, Osceola, St. Lucie, Sumter, Escambia, Orange.

Precinct shapefiles for the following counties sourced from VEST's 2020 precinct shapefile: Baker, Bradford, Broward, Calhoun, DeSoto, Dixie, Franklin, Gadsden, Gilchrist, Gulf, Hamilton, Hardee, Highlands, Holmes, Jackson, Jefferson, Lafayette, Levy, Liberty, Madison, Martin, Monroe, Okaloosa, Okeechobee, Santa Rosa, Suwannee, Taylor, Union, Wakulla, Walton, Washington. 

Precinct shapefiles for the following counties sourced from a map compiled by RDH volunteer Sebastian Pojman: Bay, Columbia, Duval, Hendry, Hernando, Indian River, Lake, Leon, Manatee, Pasco, Pinellas*, Polk, Putnam, Sarasota, Seminole*, St. Johns, Volusia.

*These two counties are from a revised version of the map.


## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
One example is:
G16PRERTRU
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
ATG - Attorney General
COA - Commissioner of Agriculture
GOV - Governor
USS - U.S. Senate
CON## - U.S. Congress
SL###  - State Legislative Lower
SU##  - State Legislative Upper

Party Codes Used:
D - Democratic
R - Republican


## Fields:
Field Name	Description
UNIQUE_ID	Unique ID for each precinct                                                                                                         
COUNTYFP	County FIP identifier
CNTY_CODE	Three-letter code for county name                                                                                                               
CNTY_NAME	Full county name                                                                                                                         
PREC_ID		Precinct ID number within county
POLL_LOC	Name of polling location

***fl_2022_gen_st_prec***                             
P22ATGDAYA Aramis Ayala                             
P22ATGDLEW Jim Lewis                                
P22ATGDUHL Daniel Uhlfelder                         
P22COADBLE Naomi Esther Blemur                      
P22COADGAI J. R. Gaillot                            
P22COADMOR Ryan Morales                             
P22COARSHA James W. Shaw                            
P22COARSIM Wilton Simpson                           
P22GOVDCRI Charlie Crist                            
P22GOVDDAN Cadance Daniel                           
P22GOVDFRI Nicole "Nikki" Fried                     
P22GOVDWIL Robert L. Willis                         
P22USSDDEL Ricardo De La Fuente                     
P22USSDDEM Val Demings                              
P22USSDRUS Brian Rush                               
P22USSDSAN William Sanchez

***fl_2022_gen_cong_prec***
CONG_DIST  Florida Congressional District                         
PCON01DJON Rebekah Jones                            
PCON01DSCH Peggy Schiller                           
PCON01RGAE Matt Gaetz                               
PCON01RLOM Mark Lombardo                            
PCON01RMER Greg Merk                                
PCON03DHAW Danielle Hawk                            
PCON03DWEL Tom Wells                                
PCON03RCAM Kat Cammack                              
PCON03RWAT Justin Waters                            
PCON04DHIL Anthony "Tony" Hill                      
PCON04DHOL LaShonda "L.J." Holloway                 
PCON04RAGU Erick Aguilar                            
PCON04RBEA Aaron Bean                               
PCON04RCHU Jon Chuba                                
PCON05RLOP Leigha "Luna" Lopez                      
PCON05RMAC Mara H. Macie                            
PCON05RRUT John H. Rutherford                       
PCON06RDAV Charles E. Davis                         
PCON06RWAL Michael Waltz                            
PCON07DFER Hilsia "Tatiana" Fernandez               
PCON07DGRE Karen Green                              
PCON07DKRU Al Krulick                               
PCON07DPAS Allek Pastrana                           
PCON07RBEN Erika Benfield                           
PCON07RDUK Brady Duke                               
PCON07REDW Ted Edwards                              
PCON07RMIL Cory Mills                               
PCON07RROB Rusty Roberts                            
PCON07RSAB Anthony Sabatini                         
PCON07RSAN Armando Al Santos                        
PCON07RSTU Scott Sturgill                           
PCON08DDOD Danelle Dodge                            
PCON08DTER Joanne Terry                             
PCON09RCAS Jose Castillo                            
PCON09RMOO Scotty Moore                             
PCON09RMOR Adianis Morales                          
PCON09RORT Sergio E. Ortiz                          
PCON10DACH Jack Achenbach                           
PCON10DAGR Alan Grayson                             
PCON10DBOO Jeffrey Boone                            
PCON10DBRA Randolph Bracy                           
PCON10DBRO Corrine Brown                            
PCON10DFRO Maxwell Alejandro Frost                  
PCON10DJAC Natalie Jackson                          
PCON10DMUN Khalid Muneer                            
PCON10DTAC Teresa Tachon                            
PCON10DTGR Terence R. Gray                          
PCON10RJON Lateresa "L.A." Jones                    
PCON10RLE  Tuan Le                                  
PCON10RLOW Thuy "Twee" Lowe                         
PCON10RMON Willie Montague                          
PCON10RWEE Peter Weed                               
PCON10RWIM Calvin B. Wimbish                        
PCON11RLOO Laura Loomer                             
PCON11RSOR Gavriel E. Soriano                       
PCON11RWEB Daniel Webster                           
PCON12RBIL Gus Michael Bilirakis                    
PCON12RLEI Chris Leiser                             
PCON12RMAR Jack Martin                              
PCON12RPER Brian Perras                             
PCON12RPRE Sid Preskitt                             
PCON13RHAY Kevin Hayslett                           
PCON13RKHE Moneer Kheireddine                       
PCON13RLUN Anna Paulina Luna                        
PCON13RMAK Amanda Makki                             
PCON13RQUI Christine Y. Quinn                       
PCON14DBRA Christopher Bradley                      
PCON14DCAS Kathy Castor                             
PCON14RJUD James Judge                              
PCON14RNAS Samar "Sam" Nashagh                      
PCON14RTOR Jerry Torres                             
PCON15DBRO Gavin Brown                              
PCON15DCOH Alan M. Cohn                             
PCON15DGEL Eddie Geller                             
PCON15DRAM Cesar Ramirez                            
PCON15DVAN William VanHorn                          
PCON15RGRI Demetries "Commander" Grimes             
PCON15RLEE Laurel Lee                               
PCON15RMCG Kevin "Mac" McGovern                     
PCON15RSTA Kelli Stargel                            
PCON15RTOL Jackie Toledo                            
PCON16RBUC Vern Buchanan                            
PCON16RHYD Martin Hyde                              
PCON18RFRA Scott Franklin                           
PCON18RHAR Kenneth "Kenny" James Hartpence          
PCON18RRAY Jennifer Raybon                          
PCON18RSCH Wendy June Schmeling                     
PCON18RTAR Eduardo "Eddie" G. Tarazona              
PCON19RDON Byron Donalds                            
PCON19RHUF Jim Huff                                 
PCON20DCHE Sheila Cherfilus                         
PCON20DHOL Dale V.C. Holness                        
PCON20DOMP Anika Omphroy                            
PCON21RBUO Jeff Buongiorno                          
PCON21RMAR Melissa Martz                            
PCON21RMAS Brian Mast                               
PCON21RSKR Ljubo Skrbic                             
PCON22RADE Deborah Adeimy                           
PCON22RARI Peter Steven Arianas                     
PCON22RDOR Rod Dorilas                              
PCON22RFRA Dan Franzese                             
PCON22RLAW Carrie Lawlor                            
PCON23DELL Allen Ellison                            
PCON23DHAM Michaelangelo Collins Hamilton           
PCON23DHOL Hava Holzhauer                           
PCON23DMOS Jared Moskowitz                          
PCON23DSOR Ben Sorensen                             
PCON23DTRO W. Michael "Mike" Trout                  
PCON23RBUD Joe Budd                                 
PCON23RCER Darlene Cerezo Swaffar                   
PCON23RCHE Steven Chess                             
PCON23RMCL Christy McLaughlin                       
PCON23RPER Myles Perrone                            
PCON23RPRU James "Jim" Pruden                       
PCON23RWEI Ira Weinstein                            
PCON24DHAR Kevin C. Harris                          
PCON24DWIL Frederica Wilson                         
PCON24RNAV Jesus G. Navarro                         
PCON24RSPI Lavern Spicer                            
PCON25DMIL Robert Millwee                           
PCON25DSCH Debbie Wasserman Schultz                 
PCON25RSPA Carla Spalding                           
PCON25RYOU Rubin Young                              
PCON26RAQU Darren Aquino                            
PCON26RDIA Mario Diaz                               
PCON27DMON Angel Montalvo                           
PCON27DRUS Ken Russell                              
PCON27DTAD Annette Taddeo                           
PCON27RPOL Frank Polo                               
PCON27RSAL Mara Elvira Salazar                     
PCON28DASE Robert Asencio                           
PCON28DPAR Juan Paredes                             
PCON28RGAR Carlos Garin                             
PCON28RGIM Carlos A. Gimenez                        
PCON28RMIL Karl "KW" Miller 

***fl_2022_gen_sldu_prec***
SLDU_DIST  Florida State Senate District                  
PSU01RBRO  Doug Broxson                             
PSU01RMIL  John Mills                               
PSU02RPIA  Regina Piazza                            
PSU02RTRU  Jay Trumbull                             
PSU05DDAV  Tracie Davis                             
PSU05DGAF  Reggie Gaffney                           
PSU07RHUT  Travis Hutson                            
PSU07RJAM  Gerry James                              
PSU08DDEM  Richard Paul Dembinsky                   
PSU08DWIL  Andrea Williams                          
PSU10RBRO  Jason Brodeur                            
PSU10RCHA  Denali Charres                           
PSU15DBRO  Kamia Brown                              
PSU15DTHO  Geraldine F. Thompson                    
PSU20RBOY  Jim Boyd                                 
PSU20RHOU  John Houman                              
PSU22RGRU  Joe Gruters                              
PSU22RJOH  Michael Johnson                          
PSU26RBYE  Steve Byers                              
PSU26RWHE  William Wheelen                          
PSU34DESC  Pitchie "Peachy" Escarment               
PSU34DIGH  Erhabor Ighodaro                         
PSU34DJON  Shevrin "Shev" Jones                     
PSU35DBOO  Lauren Book                              
PSU35DSHA  Barbara Sharief                           

***fl_2022_gen_sldl_prec***
SLDL_DIST  Florida State House District                         
PSL001RHIL Mike Hill                                
PSL001RSAL Michelle Salzman                         
PSL002RAND Alex Andrade                             
PSL002RKAR Jordan Karr                              
PSL002RLIT Greg Litton                              
PSL003RCAL Mariya Calkins                           
PSL003RRUD Joel Rudman                              
PSL005RABB Shane Abbott                             
PSL005RCOL Vance D. Coley                           
PSL005RPAT Clint Pate                               
PSL006RCLO Brian Clowdus                            
PSL006RGRI Griff Griffitts                          
PSL008DBRO Hubert Brown                             
PSL008DFRA Gallop P. Franklin                       
PSL008DJAM Gregory James                            
PSL008DLET Sharon Lettman                           
PSL008DRAT Marie Rattigan                           
PSL013DNIX Angie Nixon                              
PSL013DSMI Delaine Smith                            
PSL014DDAN Kimberly Daniels                         
PSL014DDEN Garrett Dennis                           
PSL014DHIN Iris Hinton                              
PSL014DPOL Mincy Pollock                            
PSL015RBLA Dean Black                               
PSL015RNUN Emily Nunez                              
PSL016RMIC Kiyan Michael                            
PSL016RRAY Lake Ray                                 
PSL016RSTO Chet Stokes                              
PSL017RBAK Jessica Baker                            
PSL017RMER Christina Meredith                       
PSL020RMIG Luis Miguel                              
PSL020RPAY Bobby Payne                              
PSL022DMAG Olysha Magruder                          
PSL022DPET Brandon Peters                           
PSL022RAPP Ty Appiah                                
PSL022RCLE Chuck Clemons                            
PSL023RCLO Tod Cloud                                
PSL023RMAS Ralph E. Massullo Jr                     
PSL023RREI Paul John Reinhardt                      
PSL025RCOR Liz Cornell                              
PSL025RSIL Matthew R. Silbernagel                   
PSL025RVAI Tom Vail                                 
PSL025RYAR Taylor Yarkosky                          
PSL029RBAR Webster Barnaby                          
PSL029RFET Elizabeth Fetterhoff                     
PSL030RHAT Robyn Hattaway                           
PSL030RTRA Chase Tramont                            
PSL034RBRA Robert Brackett                          
PSL034RHIL Karen Hiltz                              
PSL035DBAG Rishi Bagga                              
PSL035DKEE Tom Keen                                 
PSL035DMUN Tahitiana "T" Munoz                      
PSL035RDAV Kenneth Davenport                        
PSL035RHAW Fred Hawkins                             
PSL035RLIE Dianna Liebnitzky                        
PSL036DJOS Rod Joseph                               
PSL036DPOU Deborah Poulalion                        
PSL036RPER Angelique "Angel" Perry                  
PSL036RPLA Rachel Plakon                            
PSL036RSAN Richard Santos                           
PSL037RPLA Susan Plasencia                          
PSL037RSTA Kris Stark                               
PSL038DDOU Dominique B. Douglas                     
PSL038DHEN Sarah Henry                              
PSL038DMEA Ed Measom                                
PSL038RSMI David Smith                              
PSL038RWEI Patrick D. Weingart                      
PSL038RWUE Drake Wuertz                             
PSL039RBAN Doug Bankson                             
PSL039RHAR Charles Hart                             
PSL039RROS Randy Ross                               
PSL040DBRA LaVon Bracy Davis                        
PSL040DMYE Melissa S. Myers                         
PSL041DANT Bruce H. Antone                          
PSL041DMCC Travaris McCurdy                         
PSL041DPOW Pam Powell                               
PSL041DROS Shaniqua "Shan" Rose                     
PSL042RDWY David Dwyer                              
PSL042RJAC Bonnie Jackson                           
PSL043RROD Jay J. Rodriguez                         
PSL043RWRI Christopher Wright                       
PSL044DHAR Jennifer "Rita" Harris                   
PSL044DMOR Daisy Morales                            
PSL045RAME Carolina Amesty                          
PSL045RFRA Vennia Francois                          
PSL045RFRE Janet Frevola                            
PSL045RPOR Bruno Portigliatti                       
PSL045RZHA Mike Zhao                                
PSL047DJEN Horng "Andrew" Jeng                      
PSL047DMAR Dan Marquith                             
PSL047DNIE Anthony Nieves                           
PSL050RCAN Jennifer Canady                          
PSL050RWAL Phillip Walker                           
PSL051ROLS William "Bill" Olson                     
PSL051RTOM Josie Tomkow                             
PSL052RDAZ Rock Daze                                
PSL052RTEM John Temple                              
PSL053RHOL Jeff Holcomb                             
PSL053RKOC Anthony Kocovic                          
PSL055RPAP Gabriel Papadopoulos                     
PSL055RSOL Brad Sollberger                          
PSL055RSTE Kevin M. Steele                          
PSL056RCOC Jayden Cocuzza                           
PSL056RMOO Scott Moore                              
PSL056RYEA Brad Yeager                              
PSL058DFEN Bernard "Bernie" Fensterwald             
PSL058DSAP Joseph Saportas                          
PSL058RBER Kimberly "Kim" Berfield                  
PSL058RHOL Jason Holloway                           
PSL058RVRI Jim Vricos                               
PSL059RJAC Berny Jacques                            
PSL059RNAD Dipak D. Nadkarni                        
PSL059RWIL Jennifer Wilson                          
PSL062DNEW Wengay "Newt" Newton                     
PSL062DPHI Jesse Philippe                           
PSL062DRAY Michele K. Rayner                        
PSL065RGON Karen Gonzalez Pittman                   
PSL065RHOF Jake Hoffman                             
PSL065RMIN Michael C. Minardi                       
PSL068RHAT Paul D. Hatfield                         
PSL068RMCC Lawrence McClure                         
PSL069RALV Daniel "Danny" Alvarez                   
PSL069RPET Megan Angel Petty                        
PSL077RESP Tiffany Esposito                         
PSL077ROCO Ford OConnell                            
PSL087RCAR Mike Caruso                              
PSL087RJUS Jane Justice                             
PSL091RDUC Christina DuCasse                        
PSL091RGOS Peggy Gossett                            
PSL092DSKI Kelly Skidmore                           
PSL092DZAH Hasan Zahangir                           
PSL093DALB Shelly Lariz Albright                    
PSL093DDEN Seth Densen                              
PSL093DVAL Thomas "Tom" Valeo                       
PSL093DWAL Katherine M. Waldron                     
PSL097DDUN Lisa Dunkley                             
PSL097DFAR Saima Farooqui                           
PSL097DSCU Kelly N                                  
PSL098DHAW Patricia Hawkins                         
PSL098DJON Carmen Jones                             
PSL099DCAM Daryl Campbell                           
PSL099DMAN Elijah Manley                            
PSL101DCAS Hillary Cassel                           
PSL101DDEL Todd Delmay                              
PSL101DMIL Clay Miller                              
PSL105DSID Dr. Imran Uddin Siddiqui                 
PSL105DWOO Marie Woodson                            
PSL106DLEO Jordan W. Leonard                        
PSL106DORT Gustavo Ortega                           
PSL106RBAS Fabin Basabe                            
PSL106RROS Douglas John Ross                        
PSL106RSUT Lynn Su Sutjapojnukul                    
PSL107DBEN Christopher Benjamin                     
PSL107DFRA Wancito Francius                         
PSL108DETI Michael A. Etienne                       
PSL108DHAR Roy Hardemon                             
PSL108DJOS Dotie Joseph                             
PSL109DBUS James Bush III                           
PSL109DGAN Ashley V. Gantt                          
PSL113DALT Andrs Althabe                           
PSL113DDAM Alessandro "A.J." DAmico                 
PSL113RLOP Vicki Lopez                              
PSL113RPER Alberto Perosch                          
PSL118RFER Juan Fernandez                           
PSL118RROD Francisco Rodriguez                      
PSL118RSOT Daniel Sotelo                            
PSL119DCUE James A. Cueva                           
PSL119DGON Gabriel Gonzalez                         
PSL119RALV Ashley Alvarez                           
PSL119RGON Rob Gonzalez                             
PSL119RPOR Juan Carlos Porras                       
PSL119RSOT Jose Soto                                
PSL119RTSA Ricky Tsay                               
PSL120DGEN Adam Gentle                              
PSL120DHOR Daniel "Dan" Horton                      
PSL120RALL Robert Scott Allen                       
PSL120RLOP Rhonda Rebman Lopez                      
PSL120RMOO James "Jim" V. Mooney Jr


## Election Results Processing Notes
Precinct-level files were checked against separate countywide election result files from the Florida Department of State Election Archive (https://results.elections.myflorida.com/Index.asp?ElectionDate=8/23/2022&DATAMODE=)

For the races we were able to check, totals matched in every county except for the following: Walton, Seminole, Palm Beach, Clay, Nassau, Volusia.

Walton's precinct-level data is missing from the state's Democratic US Senate primary results. After noticing that, RDH staffed added in that data using a file from the [Walton County Supervisor of Elections](https://enr.electionsfl.org/WAL/3248/Reports/), accessed on 9/18/23. Adding that data eliminated discrepancies in Walton County between the processed precinct-level results and the state's county-level election results.

Seminole County had numerous small differences. The largest difference was 32 fewer votes in the precinct-level file for candidates PSU10RBRO and P22USSDDEM. It is not immediately clear why these differences exist.

Palm Beach, Clay, Nassau and Volusia counties have differences of less than three votes in one contest each. Those discrepancies appear to be due to recounts.

## Precinct Boundary Processing Notes
Please note that although we produced this file to be as accurate as possible, we may come across additional information in the future which may require us to update this file.

This file uses precinct boundaries from the RDH Florida 2022 General Election precinct boundary and election results file for 66 of 67 counties. Full processing notes for that file available on the RDH website. 

RDH staff collected a  precinct boundary file from Broward County after determining different boundaries were used for the primary and general elections.

Precinct boundaries in all counties were visually checked against the L2 voter file. RDH staff overlayed the compiled precinct boundary map on top of a map of voters, represented as dots located at their registered home address and colored according to their 2022 primary election precinct assignment. All boundaries appeared to encompass the correct set of voters. 

In instances when votes from the election results could not be matched to specific precincts, RDH allocated those votes proportionally to (a) precincts across the whole county or (b) precincts with shapes that likely contain those votes.  

Some precincts are split across Congressional, House of Representatives or State Senate Districts. In these cases, the precincts can be split into the particular areas contained in each district using a district shapefile and one can give the votes for the candidates in those particular districts to that district's portion of the precinct. This extra step makes block-level disaggregation and RPV analyses more accurate. For races outside of those particular districts, one does not know the proportion of votes to allot to each district-precinct chunk. As such, separate files are created to ensure the accuracy of votes. Because there were splits for Congress, House of Representatives and State Senate Districts, files for each of these levels, as well as for statewide elections, were created. 

In some cases, a precinct may have votes for multiple districts, but does not spatially intersect with all districts for which it contains votes. This could either be evidence that a precinct's boundaries are incorrect, or simply an instance in which a voter either voted or had their vote counted at the incorrect precinct. For the level-specific files mentioned above, we look into the precinct shapefiles and, unless we find a particular precinct boundary to change, these votes are dropped. For details on the exact number of votes dropped, please see the Jupyter Notebook linked below.

There is also a "fl_2022_prim_prec_no_splits" file, which contains all election results, but does not include a SLDL_DIST, SLDU_DIST or CONG_DIST column.

## Processing Steps
Visit the RDH GitHub and the processing script for precinct boundaries and election results [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection/tree/main/FL/2022)

## Additional Notes
A full raw-from-source folder containing all of the input files used to construct this file can be made available upon request.

Please direct questions related to processing this dataset to info@redistrictingdatahub.org.