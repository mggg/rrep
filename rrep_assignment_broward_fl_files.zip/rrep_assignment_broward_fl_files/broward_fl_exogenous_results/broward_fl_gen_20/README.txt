2020 Florida precinct and election results shapefile.

## RDH Date retrieval
11/10/2023

## Sources
Election results from the Florida Department of State (https://dos.myflorida.com/elections/data-statistics/elections-data/precinct-level-election-results/)

Precinct shapefiles for the following counties sourced from the respective county Supervisor of Elections: Alachua, Brevard, Broward, Collier, Columbia, DeSoto, Duval, Flagler, Gadsden, Gulf, Hardee, Hernando, Highlands, Hillsborough, Lake, Lee, Leon, Levy, Madison, Manatee, Marion, Martin, Miami-Dade, Nassau, Okaloosa, Okeechobee, Orange, Osceola, Palm Beach, Pasco, Pinellas, Polk, Putnam, Santa Rosa, St. Johns, St. Lucie, Sumter, Taylor, Union, Volusia.

Precinct shapefiles for the following counties sourced from the Florida Department of State: Bay, Bradford, Calhoun, Citrus, Clay, Dixie, Escambia, Hendry, Indian River, Sarasota, Suwannee.

Precinct shapefiles for the following counties sourced from the U.S. Census Bureau's 2020 Redistricting Data Program: Baker, Charlotte, Franklin, Gilchrist, Glades, Hamilton, Holmes, Jackson, Jefferson, Lafayette, Liberty, Monroe, Seminole, Wakulla, Walton, Washington.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G20PRERTRU
The first character is G for a general election, C for recount results, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
PRE - President

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G20PRERTRU - Donald J. Trump (Republican Party)
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREODEL - Roque "Rocky" De La Fuente (Reform Party)
G20PRESLAR - Gloria La Riva (Party for Socialism and Liberation)
G20PREGHAW - Howie Hawkin (Green Party)
G20PRECBLA - Don Blankenship (Constitution Party)
G20PREOWRI - Write-in Votes

## Processing Steps
Precinct boundaries in the following counties were edited based on the voter file, further aligned with county shapefiles or PDF maps if available: Baker, Broward, Charlotte, DeSoto, Franklin, Gulf, Hamilton, Hendry, Highlands, Hillsborough, Indian River, Jackson, Jefferson, Lafayette, Lake, Lee, Liberty, Martin, Miami-Dade, Monroe, Osceola, Palm Beach, Pasco, Polk, Putnam, St. Lucie, Suwannee, Wakulla, Washington.

Flagler 999, Lake 108, Monroe 999, Osceola 999, Palm Beach 8002 were added to the shapefile for votes reported only at the Supervisor of Elections office consistent with how most Florida counties prepare their precinct shapefiles.

Seminole County reports some early votes only by vote center. These were distributed by candidate to precincts based on their share of the precinct-level reported vote.

Miami-Dade County reports federal ballots at the congressional-district level. These were distributed by candidate to precincts in the respective congressional districts based on their share of the precinct-level reported vote.