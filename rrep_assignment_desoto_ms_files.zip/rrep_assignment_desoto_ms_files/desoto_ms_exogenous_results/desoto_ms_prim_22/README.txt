Mississippi 2022 Primary Precinct-Level Election Results and Boundaries

## RDH Date Retrieval
06/28/24

## Sources
Democratic Primary results from Mississippi Secretary of State [(here)](https://www.sos.ms.gov/elections-voting/2022-democratic-primary)
Republican Primary results from Mississippi Secretary of State [(here)](https://www.sos.ms.gov/elections-voting/2022-republican-primary)

Shapefile boundaries primarily come from [Mississippi 2022 General Election Precinct-Level Results and Boundaries](https://redistrictingdatahub.org/dataset/mississippi-2022-general-election-precinct-level-results-and-boundaries/)

The following counties come from the [VEST 2020 Mississippi file](https://redistrictingdatahub.org/dataset/vest-2020-mississippi-precinct-and-election-results/): Warren, Montgomery, Simpson, Tishomingo, Tunica, Rankin, and Amite.


## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern:
One example is:
G16PRERTRU
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
CON## - U.S. Congress

Party Codes Used:
D - Democratic
R - Republican

## Fields:
Field Name Description                                                                  
UNIQUE_ID  Unique ID for each precinct
CONG_DIST  Congressional District (this is only in the _cong file)                                                  
COUNTYFP   County FIP identifier
CNTY_CODE  County Abbreviation                                                        
CNTY_NAME  County Name                                                                  
PRECINCT   Precinct Name                                                                
PCON01DAVE US House Of Rep 01-1st Congressional District, Hunter Avery (Democrat)       
PCON01DBLA US House Of Rep 01-1st Congressional District, Dianne Black (Democrat)       
PCON01RKEL US House Of Rep 01-1st Congressional District, Trent Kelly (Republican)      
PCON01RSTR US House Of Rep 01-1st Congressional District, Mark D. Strauss (Republican)  
PCON02DKER US House Of Rep 02-2nd Congressional District, Jerry Kerner (Democrat)       
PCON02DTHO US House Of Rep 02-2nd Congressional District, Bennie G. Thompson (Democrat) 
PCON02RCAR US House Of Rep 02-2nd Congressional District, Michael Carson (Republican)   
PCON02RELL US House Of Rep 02-2nd Congressional District, Ronald Eller (Republican)     
PCON02RFLO US House Of Rep 02-2nd Congressional District, Brian Flowers (Republican)    
PCON02RJOH US House Of Rep 02-2nd Congressional District, Stanford Johnson (Republican) 
PCON03RCAS US House Of Rep 03-3rd Congressional District, Michael Cassidy (Republican)  
PCON03RGRI US House Of Rep 03-3rd Congressional District, Thomas B. Griffin (Republican)
PCON03RGUE US House Of Rep 03-3rd Congressional District, Michael Guest (Republican)    
PCON04DDUP US House Of Rep 04-4th Congressional District, Johnny L. DuPree (Democrat)   
PCON04DSEL US House Of Rep 04-4th Congressional District, David Sellers (Democrat)      
PCON04RBOY US House Of Rep 04-4th Congressional District, Carl Boyanton (Republican)    
PCON04RBRO US House Of Rep 04-4th Congressional District, Raymond N. Brooks (Republican)
PCON04REZE US House Of Rep 04-4th Congressional District, Mike Ezell (Republican)       
PCON04RPAL US House Of Rep 04-4th Congressional District, Steven M. Palazzo (Republican)
PCON04RPET US House Of Rep 04-4th Congressional District, Kidron Peterson (Republican)  
PCON04RWAG US House Of Rep 04-4th Congressional District, Clay Wagner (Republican)      
PCON04RWIG US House Of Rep 04-4th Congressional District, Brice Wiggins (Republican)    

## Processing Steps
Election results were retrieved as PDFs by county from the [Mississippi Secretary of State](https://www.sos.ms.gov/elections-voting/). 
PDFs were converted to editable text using Adobe Acrobat Pro's "Scan & OCR" feature. 
[Tabula](https://tabula.technology/) was then used to extract contest name, candidate names, and vote counts from PDFs. 
Due to formatting, precinct names needed to entered manually. To ensure accuracy, names were verified between the Republican and Democratic primaries as well as the general election results.
Additional cleaning and verification was performed in Python. All precinct-level returns sum to candidate totals for each county as well as for the state.

The shapefile primarily uses the general election shapes as a base, except in the counties listed above in sources where the 2020 general election shapes were still in place at the time of the 2022 primary election. In Rankin, North McLaurin and South McLaurin from 2020 are merged together and become South McLaurin for the 2022 primary. In Hancock, Diamondhead Central and Diamondhead East are merged together to become Diamondhead East.

The unsplit file contains all votes. The file that is split by congressional district has the following votes omitted from Madison County's Canton National Guard Armory precinct as it does not actually overlap with Congressional District 3: PCON03RCAS 1 vote, PCON03RGRI 1 vote, and PCON03RGUE 2 votes. 

Visit the RDH GitHub and the processing script for this code [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection).

Please direct questions related to processing this dataset to info@redistrictingdatahub.org.