St. Mary Parish, Louisiana RREP Assignment 

## RDH Date Retrieval
07/16/24

## Sources
Multiple, see below

This file contains the following processed datasets, each with their own accompanying README:

- Exogenous precinct boundaries and election results, from VEST (20) and RDH (22, 23)

- 2020 PL data, from the US Census Bureau, via the RDH website

- 2020 Block Shapefile, from the US Census Bureau, via the RDH website

- 2022 CVAP data, from the US Census Bureau, via the RDH website

- 2022 Election turnout data from L2 via RDH website

See assignment page for information on district maps and endogenous election results.

PL field descriptions available on the RDH website: https://redistrictingdatahub.org/data/about-our-data/pl-94171-dataset/fields-and-descriptions/




 
    