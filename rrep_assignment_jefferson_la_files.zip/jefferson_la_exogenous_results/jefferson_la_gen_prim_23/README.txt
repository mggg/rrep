Louisiana 2023 Primary and General Election Precinct Boundaries and Election Results

## RDH Date Retrieval
01/02/23

## Sources
Louisiana Secretary of State for both [11/18/2023 results](https://voterportal.sos.la.gov/static/2023-11-18) and [10/14/2023 results](https://voterportal.sos.la.gov/static/2023-10-14).

Precinct shapefile primarily from the [State of Louisiana Redistricting website](https://redist.legis.la.gov/default_ShapeFiles2020).

Election results in Ascension, Assumption, Bossier, Caddo, East Baton Rouge, Lafourche, Rapides, St. Charles, and Terrebonne parishes all contained "alpha precincts" in which votes were split by the last name of voters. These results have been combined so the results can be joined to the precinct shapefiles.

Vernon: Precinct 2A added to the precinct shapefile using data from a [Vernon Parish Police Jury District map](https://www.vppjla.com/wp-content/uploads/2023/10/VPPJ-Plan-2020-Parish-Adopted-1.pdf), adopted 12/19/2022


## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
One example is:
G16PREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
ATG - Attorney General
GOV - Governor
LTG - Lieutenant Governor
SOS - Secretary of State
TRE - Treasurer
USS - U.S. Senate
SL### - State Legislative Lower
SU## - State Legislative Upper

*Please note that the amendments fall outside of the "general / runoff" paradigm, and as such do not contain a first character marking it as such. The descriptions below note which election the amendment was on the ballot.


## Fields:
Field Name Description
UNIQUE_ID  Unique ID for each precinct                                                                                                                  
COUNTYFP   County FIP identifier                                                                                                                        
Parish     Parish Name                                                                                                                                  
Precinct   Precinct Name 
SLDL_DIST  House of Representatives District    
SLDU_DIST  State Senate District                                                                                                                                         
23A107NO   October Election, NO-:-CA No. 3 (ACT 107, 2023 - HB 47) -- Dedicates certain payments to be applied to the state retirement system unfunded accrued liability. 
23A107YES  October Election, YES-:-CA No. 3 (ACT 107, 2023 - HB 47) -- Dedicates certain payments to be applied to the state retirement system unfunded accrued liability.
23A179NO   November Election, NO-:-CA No. 3 (ACT 179, 2023 - SB 127) -- Provides for an ad valorem tax exemption for certain first responders.                             
23A179YES  November Election, YES-:-CA No. 3 (ACT 179, 2023 - SB 127) -- Provides for an ad valorem tax exemption for certain first responders.                            
23A198NO   November Election, NO-:-CA No. 4 (ACT 198, 2023 - HB 244) -- Provides relative to the use of monies in the Revenue Stabilization Trust Fund.                    
23A198YES  November Election, YES-:-CA No. 4 (ACT 198, 2023 - HB 244) -- Provides relative to the use of monies in the Revenue Stabilization Trust Fund.                   
23A199NO   November Election, NO-:-CA No. 2 (ACT 199, 2023 - HB 254) -- Repeals certain funds in the state treasury.                                                       
23A199YES  November Election, YES-:-CA No. 2 (ACT 199, 2023 - HB 254) -- Repeals certain funds in the state treasury.                                                      
23A200NO   October Election, NO-:-CA No. 1 (ACT 200, 2023 - HB 311) -- Prohibits the use of private funds in the administration of elections.                             
23A200YES  October Election, YES-:-CA No. 1 (ACT 200, 2023 - HB 311) -- Prohibits the use of private funds in the administration of elections.                            
23A278NO   November Election, NO-:-CA No. 1 (Act 278, 2022 - HB 166) -- Provides relative to timing of gubernatorial action on a bill and related matters.                 
23A278YES  November Election, YES-:-CA No. 1 (Act 278, 2022 - HB 166) -- Provides relative to timing of gubernatorial action on a bill and related matters.                
23A30NO    October Election, NO-:-CA No. 2 (ACT 30, 2023 - SB 63) -- Provides that the freedom of worship is a fundamental right worthy of the highest protection.        
23A30YES   October Election, YES-:-CA No. 2 (ACT 30, 2023 - SB 63) -- Provides that the freedom of worship is a fundamental right worthy of the highest protection.       
23A48NO    October Election, NO-:-CA No. 4 (ACT 48, 2023 - HB 46) -- Restricts ad valorem tax exemptions for certain nonprofit organizations.                             
23A48YES   October Election, YES-:-CA No. 4 (ACT 48, 2023 - HB 46) -- Restricts ad valorem tax exemptions for certain nonprofit organizations.                            
G23ATGDCHE Lindsey Cheek (DEM)-:-Attorney General                                                                                                       
G23ATGDTER Perry Walker Terrebonne (DEM)-:-Attorney General                                                                                             
G23ATGRMAL "Marty" Maley (REP)-:-Attorney General                                                                                                       
G23ATGRMUR "Liz" Baker Murrill (REP)-:-Attorney General                                                                                                 
G23ATGRSTE John Stefanski (REP)-:-Attorney General                                                                                                      
G23GOVDCOL Daniel M. "Danny" Cole (DEM)-:-Governor                                                                                                      
G23GOVDWIL Shawn D. Wilson (DEM)-:-Governor                                                                                                             
G23GOVIBAR Benjamin Barnes (IND)-:-Governor                                                                                                             
G23GOVIIST Jeffery Istre (IND)-:-Governor                                                                                                               
G23GOVILUN Hunter Lundy (IND)-:-Governor                                                                                                                
G23GOVISCU Frank Scurlock (IND)-:-Governor                                                                                                              
G23GOVNGAG "Keitron" Gagnon (NOPTY)-:-Governor                                                                                                          
G23GOVRBAR Patrick Henry "Dat" Barthel (REP)-:-Governor                                                                                                 
G23GOVRELL Xavier Ellis (REP)-:-Governor                                                                                                                
G23GOVRHEW Sharon W. Hewitt (REP)-:-Governor                                                                                                            
G23GOVRJOH "Xan" John (REP)-:-Governor                                                                                                                  
G23GOVRLAN "Jeff" Landry (REP)-:-Governor                                                                                                               
G23GOVRNEL Richard Nelson (REP)-:-Governor                                                                                                              
G23GOVRSCH John Schroder (REP)-:-Governor                                                                                                               
G23GOVRWAG Stephen "Wags" Waguespack (REP)-:-Governor                                                                                                   
G23LTGDJON Willie Jones (DEM)-:-Lieutenant Governor                                                                                                     
G23LTGIPAY Bruce Payton (IND)-:-Lieutenant Governor                                                                                                     
G23LTGNRIS Gary Rispone (NOPTY)-:-Lieutenant Governor                                                                                                   
G23LTGRGUI Elbert Guillory (REP)-:-Lieutenant Governor                                                                                                  
G23LTGRHOT "Tami" Hotard (REP)-:-Lieutenant Governor                                                                                                    
G23LTGRNUN William "Billy" Nungesser (REP)-:-Lieutenant Governor                                                                                        
G23SOSDCOL "Gwen" Collins-Greenup (DEM)-:-Secretary of State                                                                                            
G23SOSDMOR Arthur A. Morrell (DEM)-:-Secretary of State                                                                                                 
G23SOSOJEN Amanda "Smith" Jennings (OTHER)-:-Secretary of State                                                                                         
G23SOSRFRA "Mike" Francis (REP)-:-Secretary of State                                                                                                    
G23SOSRKEN Thomas J. Kennedy III (REP)-:-Secretary of State                                                                                             
G23SOSRLAN Nancy Landry (REP)-:-Secretary of State                                                                                                      
G23SOSRSCH Clay Schexnayder (REP)-:-Secretary of State                                                                                                  
G23SOSRTRO Brandon Trosclair (REP)-:-Secretary of State                                                                                                 
G23TREDGRA Dustin Granger (DEM)-:-Treasurer                                                                                                             
G23TRERFLE John Fleming (REP)-:-Treasurer                                                                                                               
G23TRERMCK Scott McKnight (REP)-:-Treasurer                                                                                                             
GSL001RLIL Randall Liles (REP)-:-State Representative --   1st Representative District                                                                  
GSL001RMCC Danny McCormick (REP)-:-State Representative --   1st Representative District                                                                
GSL002DJAC Steven Jackson (DEM)-:-State Representative --   2nd Representative District                                                                 
GSL002DVIN Terence Vinson (DEM)-:-State Representative --   2nd Representative District                                                                 
GSL004DGRE Jasmine R. Green (DEM)-:-State Representative --   4th Representative District                                                               
GSL004DJOH Lyndon B. Johnson (DEM)-:-State Representative --   4th Representative District                                                              
GSL004DWAL Joy Walters (DEM)-:-State Representative --   4th Representative District                                                                    
GSL006DDAR Robert "Bobby" Darrow (DEM)-:-State Representative --   6th Representative District                                                          
GSL006NMCM Evan McMichael (NOPTY)-:-State Representative --   6th Representative District                                                               
GSL006RMEL Michael Melerine (REP)-:-State Representative --   6th Representative District                                                               
GSL007RBAG "Larry" Bagley (REP)-:-State Representative --   7th Representative District                                                                 
GSL007RPRU "Tim" Pruitt (REP)-:-State Representative --   7th Representative District                                                                   
GSL009RHOR "Dodie" Horton (REP)-:-State Representative --   9th Representative District                                                                 
GSL009RTUR "Chris" Turner (REP)-:-State Representative --   9th Representative District                                                                 
GSL015RGAD Foy Gadberry (REP)-:-State Representative --  15th Representative District                                                                   
GSL015RROB Randall "Scotty" Robinson (REP)-:-State Representative --  15th Representative District                                                      
GSL018DPAU Shanda Paul (DEM)-:-State Representative --  18th Representative District                                                                    
GSL018RFAB Tammi Fabre (REP)-:-State Representative --  18th Representative District                                                                    
GSL018RLAC Jeremy S. LaCombe (REP)-:-State Representative --  18th Representative District                                                              
GSL019IDAV "Norm" Davis (IND)-:-State Representative --  19th Representative District                                                                   
GSL019RTHO Francis Thompson (REP)-:-State Representative --  19th Representative District                                                               
GSL020RBAT Kevin Bates (REP)-:-State Representative --  20th Representative District                                                                    
GSL020RRIS Neil Riser (REP)-:-State Representative --  20th Representative District                                                                     
GSL021DDAV James "Jamie" Davis, Jr. (DEM)-:-State Representative --  21st Representative District                                                       
GSL021DJOH C. Travis Johnson (DEM)-:-State Representative --  21st Representative District                                                              
GSL021DWHI Clark White, Jr. (DEM)-:-State Representative --  21st Representative District                                                               
GSL023DJEF Bryan Jefferson (DEM)-:-State Representative --  23rd Representative District                                                                
GSL023DMEN Shaun Mena (DEM)-:-State Representative --  23rd Representative District                                                                     
GSL023DRIC Pearl Ricks (DEM)-:-State Representative --  23rd Representative District                                                                    
GSL023DSAV Tammy M. Savoie (DEM)-:-State Representative --  23rd Representative District                                                                
GSL024RBEE Clarence Beebe (REP)-:-State Representative --  24th Representative District                                                                 
GSL024RSCH Rodney Schamerhorn (REP)-:-State Representative --  24th Representative District                                                             
GSL025RDEW Jason Dewitt (REP)-:-State Representative --  25th Representative District                                                                   
GSL025RLEL Patricia "Trish" Leleux (REP)-:-State Representative --  25th Representative District                                                        
GSL026DFRA Sandra Franklin (DEM)-:-State Representative --  26th Representative District                                                                
GSL026DLAR "Ed" Larvadain III (DEM)-:-State Representative --  26th Representative District                                                             
GSL026DWAS Reddex Washington (DEM)-:-State Representative --  26th Representative District                                                              
GSL028DRAM Ramondo "Ramram" Ramos (DEM)-:-State Representative --  28th Representative District                                                         
GSL028RDES Daryl Deshotel (REP)-:-State Representative --  28th Representative District                                                                 
GSL030IJON William "BJ" Jones (IND)-:-State Representative --  30th Representative District                                                             
GSL030ROWE Charles A. Owen (REP)-:-State Representative --  30th Representative District                                                                
GSL031RGOU Jonathan Goudeau I (REP)-:-State Representative --  31st Representative District                                                             
GSL031RHEB Troy Hebert (REP)-:-State Representative --  31st Representative District                                                                    
GSL034DCAR Wilford Carter, Sr. (DEM)-:-State Representative --  34th Representative District                                                            
GSL034DGUI Kevin D. Guidry (DEM)-:-State Representative --  34th Representative District                                                                
GSL034DLEW Franklin D. Lewis, Sr. (DEM)-:-State Representative --  34th Representative District                                                         
GSL039DJAM Mckinley James, Jr. (DEM)-:-State Representative --  39th Representative District                                                            
GSL039REME Julie Emerson (REP)-:-State Representative --  39th Representative District                                                                  
GSL040DGUI Allen Guillory (DEM)-:-State Representative --  40th Representative District                                                                 
GSL040DMIL Dustin Miller (DEM)-:-State Representative --  40th Representative District                                                                  
GSL042RHEN Chance Henry (REP)-:-State Representative --  42nd Representative District                                                                   
GSL042RLAC Douglas J. "Doug" LaCombe (REP)-:-State Representative --  42nd Representative District                                                      
GSL043DGEL Ludwig Gelobter (DEM)-:-State Representative --  43rd Representative District                                                                
GSL043RCAR "Josh" Carlson (REP)-:-State Representative --  43rd Representative District                                                                 
GSL044DCHA Tehmi Chassion (DEM)-:-State Representative --  44th Representative District                                                                 
GSL044DLEW Patrick "Pat" Lewis (DEM)-:-State Representative --  44th Representative District                                                            
GSL044DMAR Ravis K. Martinez (DEM)-:-State Representative --  44th Representative District                                                              
GSL045DLEB Paul "Scott" LeBleu (DEM)-:-State Representative --  45th Representative District                                                            
GSL045NLEB Jupiter Leblanc (NOPTY)-:-State Representative --  45th Representative District                                                              
GSL045RMYE Brach Myers (REP)-:-State Representative --  45th Representative District                                                                    
GSL048DLEV David Levy (DEM)-:-State Representative --  48th Representative District                                                                     
GSL048RBEA "Beau" Beaullieu (REP)-:-State Representative --  48th Representative District                                                               
GSL049RDER Sanders "Sandy" Derise (REP)-:-State Representative --  49th Representative District                                                         
GSL049REAT David Eaton (REP)-:-State Representative --  49th Representative District                                                                    
GSL049RLAN Jacob Landry (REP)-:-State Representative --  49th Representative District                                                                   
GSL050DROB Gloria R. Robertson (DEM)-:-State Representative --  50th Representative District                                                            
GSL050RBLA Vincent St. Blanc III (REP)-:-State Representative --  50th Representative District                                                          
GSL053RDOM Jessica Domangue (REP)-:-State Representative --  53rd Representative District                                                               
GSL053RGUI Dirk Guidry (REP)-:-State Representative --  53rd Representative District                                                                    
GSL053RTRO Willis Trosclair, Jr. (REP)-:-State Representative --  53rd Representative District                                                          
GSL057DBAI Shane Bailey (DEM)-:-State Representative --  57th Representative District                                                                   
GSL057DBUR Albert "Ali" Burl III (DEM)-:-State Representative --  57th Representative District                                                          
GSL057DNIC Rodney Nicholas (DEM)-:-State Representative --  57th Representative District                                                                
GSL057DSOR Larry Sorapuru, Jr. (DEM)-:-State Representative --  57th Representative District                                                            
GSL057DSWE Michelle Sweeney (DEM)-:-State Representative --  57th Representative District                                                               
GSL057DTAY Sylvia Taylor (DEM)-:-State Representative --  57th Representative District                                                                  
GSL057NWIS Russell "Russ" Wise (NOPTY)-:-State Representative --  57th Representative District                                                          
GSL057RPER Shondrell Perrilloux (REP)-:-State Representative --  57th Representative District                                                           
GSL062DADA Roy Daryl Adams (DEM)-:-State Representative --  62nd Representative District                                                                
GSL062DBAN Daniel Banguel (DEM)-:-State Representative --  62nd Representative District                                                                 
GSL062DLAN Dadrius Lanus (DEM)-:-State Representative --  62nd Representative District                                                                  
GSL063DBAN Chauna Banks (DEM)-:-State Representative --  63rd Representative District                                                                   
GSL063DCAR Barbara West Carpenter (DEM)-:-State Representative --  63rd Representative District                                                         
GSL063RLEM Christopher Lemoine (REP)-:-State Representative --  63rd Representative District                                                            
GSL064RALF Kellie Alford (REP)-:-State Representative --  64th Representative District                                                                  
GSL064RDIC Kellee Hennessy Dickerson (REP)-:-State Representative --  64th Representative District                                                      
GSL064RTAL "Garry Frog" Talbert (REP)-:-State Representative --  64th Representative District                                                           
GSL065RIVE Brandon Ivey (REP)-:-State Representative --  65th Representative District                                                                   
GSL065RMOA Aaron Moak (REP)-:-State Representative --  65th Representative District                                                                     
GSL065RPOP Jamie Pope (REP)-:-State Representative --  65th Representative District                                                                     
GSL065RVEN Lauren Ventrella (REP)-:-State Representative --  65th Representative District                                                               
GSL065RWHI Stephen Whitlow (REP)-:-State Representative --  65th Representative District                                                                
GSL066RAPP Monique Appeaning (REP)-:-State Representative --  66th Representative District                                                              
GSL066RCHE Emily Chenevert (REP)-:-State Representative --  66th Representative District                                                                
GSL066RDAY Hollis "Bubbe" Day (REP)-:-State Representative --  66th Representative District                                                             
GSL066REDM "Richie" Edmonds (REP)-:-State Representative --  66th Representative District                                                               
GSL066RMAR Drew Maranto (REP)-:-State Representative --  66th Representative District                                                                   
GSL068DDAV Belinda Creel Davis (DEM)-:-State Representative --  68th Representative District                                                            
GSL068DGRO Robert "Max" Grodner, Jr. (DEM)-:-State Representative --  68th Representative District                                                      
GSL068NTHO Parry "Matt" Thomas (NOPTY)-:-State Representative --  68th Representative District                                                          
GSL068RADA Laura White "Laurie" Adams (REP)-:-State Representative --  68th Representative District                                                     
GSL068RMCM Dixon McMakin (REP)-:-State Representative --  68th Representative District                                                                  
GSL070DMYE "Steve" Myers (DEM)-:-State Representative --  70th Representative District                                                                  
GSL070RCAM Brent Campanella (REP)-:-State Representative --  70th Representative District                                                               
GSL070RFRE Barbara Reich Freiberg (REP)-:-State Representative --  70th Representative District                                                         
GSL070RSEA Jennie Seals (REP)-:-State Representative --  70th Representative District                                                                   
GSL071RAVA Walley Avara (REP)-:-State Representative --  71st Representative District                                                                   
GSL071RNOR "Jim" Norred (REP)-:-State Representative --  71st Representative District                                                                   
GSL071RWIL Roger Wilder III (REP)-:-State Representative --  71st Representative District                                                               
GSL072DCAR "Robby" Carter (DEM)-:-State Representative --  72nd Representative District                                                                 
GSL072DMAT Roderick "Devon" Matthews (DEM)-:-State Representative --  72nd Representative District                                                      
GSL073RCHA Michael Chatellier (REP)-:-State Representative --  73rd Representative District                                                             
GSL073RCOA Kimberly Landry Coates (REP)-:-State Representative --  73rd Representative District                                                         
GSL073RLEB Braville J. LeBlanc (REP)-:-State Representative --  73rd Representative District                                                            
GSL074RDUT Louis "Lou" Dutel (REP)-:-State Representative --  74th Representative District                                                              
GSL074REGA Peter Egan (REP)-:-State Representative --  74th Representative District                                                                     
GSL074RSIN Buffie Singletary (REP)-:-State Representative --  74th Representative District                                                              
GSL075DMAY Kelvin May (DEM)-:-State Representative --  75th Representative District                                                                     
GSL075RTAL Jacob "Perry" Talley (REP)-:-State Representative --  75th Representative District                                                           
GSL075RWYB John Wyble (REP)-:-State Representative --  75th Representative District                                                                     
GSL076RBER Stephanie Hunter Berault (REP)-:-State Representative --  76th Representative District                                                       
GSL076RJON Shawn Jones (REP)-:-State Representative --  76th Representative District                                                                    
GSL081RAMA Jason Amato (REP)-:-State Representative --  81st Representative District                                                                    
GSL081RWIL Jeffrey F. "Jeff" Wiley (REP)-:-State Representative --  81st Representative District                                                        
GSL083DGRE Kyle M. Green, Jr. (DEM)-:-State Representative --  83rd Representative District                                                             
GSL083RJAS Reginald Jasmin (REP)-:-State Representative --  83rd Representative District                                                                
GSL085DMAN Andrea Manuel (DEM)-:-State Representative --  85th Representative District                                                                  
GSL085NBEN Andrew Bennett (NOPTY)-:-State Representative --  85th Representative District                                                               
GSL085RCOX Vincent E. Cox III (REP)-:-State Representative --  85th Representative District                                                             
GSL087DLYO Rodney Lyons, Sr. (DEM)-:-State Representative --  87th Representative District                                                              
GSL087DMAC Trent Mackey, Jr. (DEM)-:-State Representative --  87th Representative District                                                              
GSL088REDM Kathy Edmonston (REP)-:-State Representative --  88th Representative District                                                                
GSL088RROB Willie Robinson (REP)-:-State Representative --  88th Representative District                                                                
GSL088RSCH Donald "Don" Schexnaydre (REP)-:-State Representative --  88th Representative District                                                       
GSL089RALL Joshua "Josh" Allison (REP)-:-State Representative --  89th Representative District                                                          
GSL089RCAR Kim Carver (REP)-:-State Representative --  89th Representative District                                                                     
GSL089RCAS Hugh Cassidy (REP)-:-State Representative --  89th Representative District                                                                   
GSL089RNOW Scott Nowicki (REP)-:-State Representative --  89th Representative District                                                                  
GSL090LALE Heide Alejandro-Smith (LBT)-:-State Representative --  90th Representative District                                                          
GSL090RDUB Mary DuBuisson (REP)-:-State Representative --  90th Representative District                                                                 
GSL090RGLO Brian Glorioso (REP)-:-State Representative --  90th Representative District                                                                 
GSL091DCAR Edward "Ed" Carlson (DEM)-:-State Representative --  91st Representative District                                                            
GSL091DLAN Mandie Landry (DEM)-:-State Representative --  91st Representative District                                                                  
GSL091DOMA Madison O'Malley (DEM)-:-State Representative --  91st Representative District                                                               
GSL092RSIG Michael "Mike" Sigur (REP)-:-State Representative --  92nd Representative District                                                           
GSL092RSTA "Joe" Stagni (REP)-:-State Representative --  92nd Representative District                                                                   
GSL094RHIL Stephanie Hilferty (REP)-:-State Representative --  94th Representative District                                                             
GSL094RMAR Charles E. Marsala (REP)-:-State Representative --  94th Representative District                                                             
GSL095RELL Aaron Ellis (REP)-:-State Representative --  95th Representative District                                                                    
GSL095RMAC Shane Mack (REP)-:-State Representative --  95th Representative District                                                                     
GSL103DRIL Stacy Riley, Sr. (DEM)-:-State Representative -- 103rd Representative District                                                               
GSL103RBAY "Mike" Bayham (REP)-:-State Representative -- 103rd Representative District                                                                  
GSL103RLEW Richard "Richie" Lewis (REP)-:-State Representative -- 103rd Representative District                                                         
GSL104RGAL "Jay" Gallé (REP)-:-State Representative -- 104th Representative District                                                                    
GSL104RRAY John Raymond (REP)-:-State Representative -- 104th Representative District                                                                   
GSL105DCAP Joanna Cappiello-Leopold (DEM)-:-State Representative -- 105th Representative District                                                       
GSL105DCOR Mack Cormier (DEM)-:-State Representative -- 105th Representative District                                                                   
GSL105RBRA Jacob Braud (REP)-:-State Representative -- 105th Representative District                                                                    
GSL105RVAL Donald "Don" Vallee (REP)-:-State Representative -- 105th Representative District                                                            
GSU01RGAR  "Ray" Garofalo (REP)-:-State Senator --  1st Senatorial District                                                                             
GSU01ROWE  Robert "Bob" Owen (REP)-:-State Senator --  1st Senatorial District                                                                          
GSU02DPRI  Edward "Ed" Price (DEM)-:-State Senator --  2nd Senatorial District                                                                          
GSU02RDEL  "Chris" Delpit (REP)-:-State Senator --  2nd Senatorial District                                                                             
GSU06REDM  "Rick" Edmonds (REP)-:-State Senator --  6th Senatorial District                                                                             
GSU06RIVE  Barry Ivey (REP)-:-State Senator --  6th Senatorial District                                                                                 
GSU08RCON  Patrick Connick (REP)-:-State Senator --  8th Senatorial District                                                                            
GSU08RKER  Timothy Kerner, Jr. (REP)-:-State Senator --  8th Senatorial District                                                                        
GSU09DMUS  Mary Anne Mushatt (DEM)-:-State Senator --  9th Senatorial District                                                                          
GSU09RHEN  J. Cameron Henry, Jr. (REP)-:-State Senator --  9th Senatorial District                                                                      
GSU12DGON  Brittany "Britt" Gondolfi (DEM)-:-State Senator -- 12th Senatorial District                                                                  
GSU12DKAT  Gloria W. Kates (DEM)-:-State Senator -- 12th Senatorial District                                                                            
GSU12RMIZ  "Beth" Mizell (REP)-:-State Senator -- 12th Senatorial District                                                                              
GSU13RHOD  Valarie Hodges (REP)-:-State Senator -- 13th Senatorial District                                                                             
GSU13RMIN  "Buddy" Mincey, Jr. (REP)-:-State Senator -- 13th Senatorial District                                                                        
GSU19DBEL  Marilyn Bellock (DEM)-:-State Senator -- 19th Senatorial District                                                                            
GSU19RMIL  Gregory A. Miller (REP)-:-State Senator -- 19th Senatorial District                                                                          
GSU20RCAR  "Dave" Carskadon (REP)-:-State Senator -- 20th Senatorial District                                                                           
GSU20RFES  Michael "Big Mike" Fesi (REP)-:-State Senator -- 20th Senatorial District                                                                    
GSU21RALL  Robert Allain (REP)-:-State Senator -- 21st Senatorial District                                                                              
GSU21RLAG  Henry "Bo" LaGrange (REP)-:-State Senator -- 21st Senatorial District                                                                        
GSU21RSWI  Stephen Swiber (REP)-:-State Senator -- 21st Senatorial District                                                                             
GSU22DMIT  Melinda Narcisse "Mel" Mitchell (DEM)-:-State Senator -- 22nd Senatorial District                                                            
GSU22DXAN  Phanat "PX" Xanamane (DEM)-:-State Senator -- 22nd Senatorial District                                                                       
GSU22ILAT  Dexter T. Lathan (IND)-:-State Senator -- 22nd Senatorial District                                                                           
GSU22RAND  Hugh Andre (REP)-:-State Senator -- 22nd Senatorial District                                                                                 
GSU22RMIG  Blake Miguez (REP)-:-State Senator -- 22nd Senatorial District                                                                               
GSU25DLEW  Joshua "Josh" Lewis (DEM)-:-State Senator -- 25th Senatorial District                                                                        
GSU25RABR  Mark Abraham (REP)-:-State Senator -- 25th Senatorial District                                                                               
GSU31RMCC  "Mike" McConathy (REP)-:-State Senator -- 31st Senatorial District                                                                           
GSU31RSEA  Alan Seabaugh (REP)-:-State Senator -- 31st Senatorial District                                                                              
GSU33RCAT  Stewart Cathey, Jr. (REP)-:-State Senator -- 33rd Senatorial District                                                                        
GSU33RWHI  Harvey "Ned" White (REP)-:-State Senator -- 33rd Senatorial District                                                                         
GSU34DJAC  Katrina Jackson (DEM)-:-State Senator -- 34th Senatorial District                                                                            
GSU34RSMI  James "Joeboy" Smith (REP)-:-State Senator -- 34th Senatorial District                                                                       
GSU36RBAS  "Adam" Bass (REP)-:-State Senator -- 36th Senatorial District                                                                                
GSU36RMIL  Robert Mills (REP)-:-State Senator -- 36th Senatorial District                                                                               
GSU37ISCI  Ivan M. Scioneaux, Jr. (IND)-:-State Senator -- 37th Senatorial District                                                                     
GSU37RBUS  Randy Bush (REP)-:-State Senator -- 37th Senatorial District                                                                                 
GSU37RWHE  "Bill" Wheat (REP)-:-State Senator -- 37th Senatorial District                                                                               
GSU38RJEN  Chase Jennings (REP)-:-State Senator -- 38th Senatorial District                                                                             
GSU38RMIL  John Milkovich (REP)-:-State Senator -- 38th Senatorial District                                                                             
GSU38RPRE  Thomas A. Pressly (REP)-:-State Senator -- 38th Senatorial District                                                                          
GSU39DGLO  Cedric B. Glover (DEM)-:-State Senator -- 39th Senatorial District                                                                           
GSU39DJEN  Samuel L. "Sam" Jenkins, Jr. (DEM)-:-State Senator -- 39th Senatorial District                                                               
GSU39DNOR  Barbara M. Norton (DEM)-:-State Senator -- 39th Senatorial District                                                                          
GSU39RSLA  James F. "Jim" Slagle (REP)-:-State Senator -- 39th Senatorial District                                                                      
R23ATGDCHE Lindsey Cheek (DEM)-:-Attorney General                                                                                                       
R23ATGRMUR "Liz" Baker Murrill (REP)-:-Attorney General                                                                                                 
R23SOSDCOL "Gwen" Collins-Greenup (DEM)-:-Secretary of State                                                                                            
R23SOSRLAN Nancy Landry (REP)-:-Secretary of State                                                                                                      
R23TREDGRA Dustin Granger (DEM)-:-Treasurer                                                                                                             
R23TRERFLE John Fleming (REP)-:-Treasurer                                                                                                               
RSL004DGRE Jasmine R. Green (DEM)-:-State Representative --   4th Representative District                                                               
RSL004DWAL Joy Walters (DEM)-:-State Representative --   4th Representative District                                                                    
RSL018RFAB Tammi Fabre (REP)-:-State Representative --  18th Representative District                                                                    
RSL018RLAC Jeremy S. LaCombe (REP)-:-State Representative --  18th Representative District                                                              
RSL021DDAV James "Jamie" Davis, Jr. (DEM)-:-State Representative --  21st Representative District                                                       
RSL021DJOH C. Travis Johnson (DEM)-:-State Representative --  21st Representative District                                                              
RSL023DMEN Shaun Mena (DEM)-:-State Representative --  23rd Representative District                                                                     
RSL023DSAV Tammy M. Savoie (DEM)-:-State Representative --  23rd Representative District                                                                
RSL053RDOM Jessica Domangue (REP)-:-State Representative --  53rd Representative District                                                               
RSL053RGUI Dirk Guidry (REP)-:-State Representative --  53rd Representative District                                                                    
RSL057DTAY Sylvia Taylor (DEM)-:-State Representative --  57th Representative District                                                                  
RSL057NWIS Russell "Russ" Wise (NOPTY)-:-State Representative --  57th Representative District                                                          
RSL063DBAN Chauna Banks (DEM)-:-State Representative --  63rd Representative District                                                                   
RSL063DCAR Barbara West Carpenter (DEM)-:-State Representative --  63rd Representative District                                                         
RSL064RALF Kellie Alford (REP)-:-State Representative --  64th Representative District                                                                  
RSL064RDIC Kellee Hennessy Dickerson (REP)-:-State Representative --  64th Representative District                                                      
RSL065RIVE Brandon Ivey (REP)-:-State Representative --  65th Representative District                                                                   
RSL065RVEN Lauren Ventrella (REP)-:-State Representative --  65th Representative District                                                               
RSL066RCHE Emily Chenevert (REP)-:-State Representative --  66th Representative District                                                                
RSL066REDM "Richie" Edmonds (REP)-:-State Representative --  66th Representative District                                                               
RSL068DDAV Belinda Creel Davis (DEM)-:-State Representative --  68th Representative District                                                            
RSL068RMCM Dixon McMakin (REP)-:-State Representative --  68th Representative District                                                                  
RSL070DMYE "Steve" Myers (DEM)-:-State Representative --  70th Representative District                                                                  
RSL070RFRE Barbara Reich Freiberg (REP)-:-State Representative --  70th Representative District                                                         
RSL074REGA Peter Egan (REP)-:-State Representative --  74th Representative District                                                                     
RSL074RSIN Buffie Singletary (REP)-:-State Representative --  74th Representative District                                                              
RSL075DMAY Kelvin May (DEM)-:-State Representative --  75th Representative District                                                                     
RSL075RWYB John Wyble (REP)-:-State Representative --  75th Representative District                                                                     
RSL089RALL Joshua "Josh" Allison (REP)-:-State Representative --  89th Representative District                                                          
RSL089RCAR Kim Carver (REP)-:-State Representative --  89th Representative District                                                                     
RSL090RDUB Mary DuBuisson (REP)-:-State Representative --  90th Representative District                                                                 
RSL090RGLO Brian Glorioso (REP)-:-State Representative --  90th Representative District                                                                 
RSL103RBAY "Mike" Bayham (REP)-:-State Representative -- 103rd Representative District                                                                  
RSL103RLEW Richard "Richie" Lewis (REP)-:-State Representative -- 103rd Representative District                                                         
RSL105DCOR Mack Cormier (DEM)-:-State Representative -- 105th Representative District                                                                   
RSL105RBRA Jacob Braud (REP)-:-State Representative -- 105th Representative District                                                                    
RSU21RALL  Robert Allain (REP)-:-State Senator -- 21st Senatorial District                                                                              
RSU21RLAG  Henry "Bo" LaGrange (REP)-:-State Senator -- 21st Senatorial District                                                                        
RSU39DGLO  Cedric B. Glover (DEM)-:-State Senator -- 39th Senatorial District                                                                           
RSU39DJEN  Samuel L. "Sam" Jenkins, Jr. (DEM)-:-State Senator -- 39th Senatorial District                                                               
                                                                                                                              

## Processing Steps
Absentee votes and other votes recorded at the parish-level are allocated to precincts based on each precincts share of precinct-level vote in that parish for that particular candidate.

Visit the RDH GitHub and the processing script for this code [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection).

Louisiana's precinct shapefiles were compared against an individual-level Louisiana voterfile via L2 dated 11/20/23.

Please direct questions related to processing this dataset to info@redistrictingdatahub.org.
