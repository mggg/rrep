Alabama 2022 Primary Election Results and Boundaries

## RDH Date Retrieval
10/05/23

## Sources
[Alabama Secretary of State](https://www.sos.alabama.gov/alabama-votes/voter/election-data)

All county shapes were sourced from [RDH's Alabama 2022 General Election Shapefile](https://redistrictingdatahub.org/dataset/alabama-2022-general-election-precinct-level-results-and-boundaries/).
Jefferson County has modified precinct boundaries based on voter file data.
The following counties have precincts whose names in the shapefile are modified to join with the correct election results - Autauga, Baldwin, Bibb, Blount, Bullock, Butler, Calhoun, Cherokee, Chilton, Choctaw, Clarke, Coffee, Colbert, Conecuh, Coosa, Covington, Crenshaw, Cullman, Dallas, DeKalb, Elmore, Etowah, Fayette, Franklin, Hale, Henry, Houston, Jefferson, Lauderdale, Lawrence, Lee, Macon, Madison, Marion, Marshall, Mobile, Monroe, Montgomery, Morgan, Pickens, Pike, St. Clair, Talladega, Tallapoosa, Tuscaloosa, Walker and Wilcox.

## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
One example is:
G16PREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature, Public Service Commissioners and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
A## - Proposed Statewide Amendement
AGR - Commissioner of Agriculture
ATG - Attorney General
AUD - State Auditor
BOE## - State Board of Education
GOV - Governor
PS# - Public Service Commissioner
SOS - Secretary Of State
USS - United States Senator
CON## - U.S. Congress
SL###  - State Legislative Lower
SU##  - State Legislative Upper
SSC - Associate Justice State Supreme Court

Party Codes Used:
D - Democratic
R - Republican

All fields below are present in the al_prim_22_no_splits_prec file.

## Fields:
Field Name Description 
UNIQUE_ID  Unique Precinct Identifier                                                           
COUNTYFP   County FIP Identifier                                                                 
county     County Name                                                                           
precinct   Precinct Identifier 

***al_prim_22_st_prec***                                                           
G22A01NO   No - PROPOSED STATEWIDE AMENDMENT NUMBER ONE                              
G22A01YES  Yes - PROPOSED STATEWIDE AMENDMENT NUMBER ONE                             
P22USSDBOY Boyd, Will - UNITED STATES SENATOR - DEM                                              
P22USSDDEA Dean, Brandaun - UNITED STATES SENATOR - DEM                                          
P22USSDJAC Jackson, Lanny - UNITED STATES SENATOR - DEM                                          
P22USSRBRI Britt, Katie - UNITED STATES SENATOR - REP                                            
P22USSRBRO Brooks, Mo - UNITED STATES SENATOR - REP                                              
P22USSRDUR Durant, Mike - UNITED STATES SENATOR - REP                                            
P22USSRSCH Schafer, Jake - UNITED STATES SENATOR - REP                                           
P22USSRDUP Dupriest, Karla M. - UNITED STATES SENATOR - REP                                      
P22USSRBOD Boddie, Lillie - UNITED STATES SENATOR - REP                                          
P22GOVDFLO Flowers, Yolanda Rochelle - GOVERNOR - DEM                                            
P22GOVDFOR Fortier, Malika Sanders - GOVERNOR - DEM                                              
P22GOVDJAM Jamieson, Patricia Salter - GOVERNOR - DEM                                            
P22GOVDKEN Kennedy, Arthur - GOVERNOR - DEM                                                      
P22GOVDSMI Smith, Doug "New Blue" - GOVERNOR - DEM                                               
P22GOVDMAR Martin, Chad "Chig" - GOVERNOR - DEM                                                  
P22GOVRIVE Ivey, Kay - GOVERNOR - REP                                                            
P22GOVRBLA Blanchard, Lindy - GOVERNOR - REP                                                     
P22GOVRJAM James, Tim - GOVERNOR - REP                                                           
P22GOVRBUR Burdette, Lew - GOVERNOR - REP                                                        
P22GOVRODL Odle, Dean - GOVERNOR - REP                                                           
P22GOVRJON Jones, Donald Trent - GOVERNOR - REP                                                  
P22GOVRTHO Thomas, Dave - GOVERNOR - REP                                                         
P22GOVRGEO George, Stacy Lee - GOVERNOR - REP                                                    
P22GOVRYOU Young, Dean - GOVERNOR - REP                                                          
P22ATGRMAR Marshall, Steve - ATTORNEY GENERAL - REP                                              
P22ATGRSTI Still, Harry Bartlett Still III - ATTORNEY GENERAL - REP                                    
P22SOSRZEI Zeigler, Jim - SECRETARY OF STATE - REP                                               
P22SOSRALL Allen, Wes - SECRETARY OF STATE - REP                                                 
P22SOSRHOR Horn, Christian - SECRETARY OF STATE - REP                                            
P22SOSRPAC Packard, Ed - SECRETARY OF STATE - REP                                                
P22AUDRSOR Sorrell, Andrew - STATE AUDITOR - REP                                                 
P22AUDRCOO Cooke, Stan - STATE AUDITOR - REP                                                     
P22AUDRGLO Glover, Rusty - STATE AUDITOR - REP                                                   
PBOE02RWES West, Tracie - STATE BOARD OF EDUCATION MEMBER DISTRICT 2 - REP                       
PBOE02RBAL Balkcum, Alex - STATE BOARD OF EDUCATION MEMBER DISTRICT 2 - REP                      
PBOE06RMAN Manning, Marie - STATE BOARD OF EDUCATION MEMBER DISTRICT 6 - REP                     
PBOE06RYOT Yother, Priscilla - STATE BOARD OF EDUCATION MEMBER DISTRICT 6 - REP                  
PBOE08RREY Reynolds, Wayne - STATE BOARD OF EDUCATION MEMBER DISTRICT 8 - REP                    
PBOE08RDAV Davis, Rex - STATE BOARD OF EDUCATION MEMBER DISTRICT 8 - REP                         
P22PS1RODE Oden, Jeremy H. - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                            
P22PS1RWOO Woodall, Brent - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                             
P22PS1RHAM Hammock, John - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                              
P22PS1RMCL McLamb, Stephen - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                            
P22PS2RBEE Beeker, Chip - PUBLIC SERVICE COMMISSION, PLACE 2 - REP                               
P22PS2RMCC McCollum, Robert L. - PUBLIC SERVICE COMMISSION, PLACE 2 - REP                        
P22PS2RLIT Litaker, Robin - PUBLIC SERVICE COMMISSION, PLACE 2 - REP                             
PSSC5RCOO  Cook, Greg - ASSOCIATE JUSTICE OF THE SUPREME COURT, PLACE 5 - REP                    
PSSC5RJON  Jones, Debra - ASSOCIATE JUSTICE OF THE SUPREME COURT, PLACE 5 - REP                                               

***al_prim_22_cong_prec***
CONG_DIST Alabama Congressional District 
PCON02DHAR Harvey-Hall, Phyllis - UNITED STATES REPRESENTATIVE, 2ND CONGRESSIONAL DISTRICT - DEM 
PCON02DPAT Patel, Vimal - UNITED STATES REPRESENTATIVE, 2ND CONGRESSIONAL DISTRICT - DEM         
PCON03RROG Rogers, Mike - UNITED STATES REPRESENTATIVE, 3RD CONGRESSIONAL DISTRICT - REP         
PCON03RJOI Joiner, Michael T. - UNITED STATES REPRESENTATIVE, 3RD CONGRESSIONAL DISTRICT - REP   
PCON04DNEI Neighbors, Rick - UNITED STATES REPRESENTATIVE, 4TH CONGRESSIONAL DISTRICT - DEM      
PCON04DGOR Gore, Rhonda - UNITED STATES REPRESENTATIVE, 4TH CONGRESSIONAL DISTRICT - DEM         
PCON05DWAR Warner-Stanton, Kathy - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - DEM
PCON05DTHO Thompson, Charlie - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - DEM    
PCON05RSTR Strong, Dale - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP         
PCON05RWAR Wardynski, Casey - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP     
PCON05RROB Roberts, John - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP        
PCON05RSAN Sanford, Paul - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP        
PCON05RBLA Blalock, Andy - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP        
PCON05RWRI Wright, Harrison - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP 

***al_prim_22_sldu_prec***
SLDU_DIST  Alabama State Senate District           
PSU01RMEL  Melson, Tim - STATE SENATOR, DISTRICT 1 - REP                                         
PSU01RSUT  Sutherland, John - STATE SENATOR, DISTRICT 1 - REP                                    
PSU02RBUT  Butler, Tom - STATE SENATOR, DISTRICT 2 - REP                                         
PSU02RHOL  Holtzclaw, Bill - STATE SENATOR, DISTRICT 2 - REP                                     
PSU11RBEL  Bell, Lance - STATE SENATOR, DISTRICT 11 - REP                                        
PSU11RWRI  Wright, Michael J - STATE SENATOR, DISTRICT 11 - REP                                  
PSU12RDRA  Draper, Wendy Ghee - STATE SENATOR, DISTRICT 12 - REP                                 
PSU12RKEL  Kelley, Keith - STATE SENATOR, DISTRICT 12 - REP                                      
PSU12RWIL  Willis, Wayne - STATE SENATOR, DISTRICT 12 - REP                                      
PSU13RPRI  Price, Randy - STATE SENATOR, DISTRICT 13 - REP                                       
PSU13RCOK  Coker, John Allen - STATE SENATOR, DISTRICT 13 - REP                                  
PSU15RROB  Roberts, Dan - STATE SENATOR, DISTRICT 15 - REP                                       
PSU15RCHR  Christine, Brian - STATE SENATOR, DISTRICT 15 - REP                                   
PSU17RSHE  Shelnutt, Shay - STATE SENATOR, DISTRICT 17 - REP                                     
PSU17RDUN  Dunn, Mike - STATE SENATOR, DISTRICT 17 - REP                                         
PSU19DCOL  Coleman, Merika - STATE SENATOR, DISTRICT 19 - DEM                                    
PSU19DALE  Alexander, Louise "Lulu" - STATE SENATOR, DISTRICT 19 - DEM                           
PSU20DCOL  Coleman-Madison, Linda - STATE SENATOR, DISTRICT 20 - DEM                             
PSU20DHUN  Huntley, Rodney - STATE SENATOR, DISTRICT 20 - DEM                                    
PSU22RALB  Albritton, Greg - STATE SENATOR, DISTRICT 22 - REP                                    
PSU22RSEX  Sexton, Stephen - STATE SENATOR, DISTRICT 22 - REP                                    
PSU23DSAN  Sanders, Hank - STATE SENATOR, DISTRICT 23 - DEM                                      
PSU23DSTE  Stewart, Robert L. - STATE SENATOR, DISTRICT 23 - DEM                                 
PSU23DMEL  Melton, Darrio - STATE SENATOR, DISTRICT 23 - DEM                                     
PSU23DSPE  Spencer, Thayer "Bear" - STATE SENATOR, DISTRICT 23 - DEM                             
PSU27RHOV  Hovey, Jay - STATE SENATOR, DISTRICT 27 - REP                                         
PSU27RWHA  Whatley, Tom - STATE SENATOR, DISTRICT 27 - REP                                       
PSU28DBEA  Beasley, Billy - STATE SENATOR, DISTRICT 28 - DEM                                     
PSU28DLEE  Lee, Frank "Chris" - STATE SENATOR, DISTRICT 28 - DEM                                 
PSU31RCAR  Carnley, Josh - STATE SENATOR, DISTRICT 31 - REP                                      
PSU31RJON  Jones, Mike Jr, - STATE SENATOR, DISTRICT 31 - REP                                   
PSU31RHOR  Horton, Stormin Norman - STATE SENATOR, DISTRICT 31 - REP                                                                     

***al_prim_22_sldl_prec***
SLDL_DIST Alabama State House District
PSL001RPET Pettus, Phillip - STATE REPRESENTATIVE, DISTRICT 1 - REP                              
PSL001RMCC McCaney, Maurice - STATE REPRESENTATIVE, DISTRICT 1 - REP                                   
PSL002RHAR Harrison, Ben - STATE REPRESENTATIVE, DISTRICT 2 - REP                                
PSL002RBLA Black, Jason Spencer - STATE REPRESENTATIVE, DISTRICT 2 - REP                         
PSL002RBUT Butler, Kimberly - STATE REPRESENTATIVE, DISTRICT 2 - REP                             
PSL002RIRE Irelan, Terrance L. - STATE REPRESENTATIVE, DISTRICT 2 - REP                          
PSL003DTHO Thompson, Wesley - STATE REPRESENTATIVE, DISTRICT 3 - DEM                             
PSL003DBEN Bentley, Susan Warren - STATE REPRESENTATIVE, DISTRICT 3 - DEM                        
PSL003RUND Underwood, Kerry "Bubba" - STATE REPRESENTATIVE, DISTRICT 3 - REP                     
PSL003RJOL Joly, Fred - STATE REPRESENTATIVE, DISTRICT 3 - REP                                   
PSL004RMOO Moore, Parker Duncan - STATE REPRESENTATIVE, DISTRICT 4 - REP                         
PSL004RJOH Johnson, Patrick - STATE REPRESENTATIVE, DISTRICT 4 - REP                             
PSL004RBAN Banister, Sheila - STATE REPRESENTATIVE, DISTRICT 4 - REP                             
PSL007RYAR Yarbrough, Ernie - STATE REPRESENTATIVE, DISTRICT 7 - REP                             
PSL007RROB Robertson, Proncey D. - STATE REPRESENTATIVE, DISTRICT 7 - REP                        
PSL013RWOO Woods, Matt - STATE REPRESENTATIVE, DISTRICT 13 - REP                                 
PSL013RWAI Waits, Charlie - STATE REPRESENTATIVE, DISTRICT 13 - REP                              
PSL013RBAR Barnes, Greg - STATE REPRESENTATIVE, DISTRICT 13 - REP                                
PSL013RDAV Davis, Keith - STATE REPRESENTATIVE, DISTRICT 13 - REP                                
PSL013RDOZ Dozier, Matt - STATE REPRESENTATIVE, DISTRICT 13 - REP                                
PSL014RWAD Wadsworth, Timothy (Tim) - STATE REPRESENTATIVE, DISTRICT 14 - REP                    
PSL014RFRE Fredricks, Tom - STATE REPRESENTATIVE, DISTRICT 14 - REP                              
PSL014RFRA Franks, Cory - STATE REPRESENTATIVE, DISTRICT 14 - REP                                
PSL015RHUL Hulsey, Leigh - STATE REPRESENTATIVE, DISTRICT 15 - REP                               
PSL015RTOM Tompkins, Brad - STATE REPRESENTATIVE, DISTRICT 15 - REP                              
PSL020RLOM Lomax, James - STATE REPRESENTATIVE, DISTRICT 20 - REP                                
PSL020RTAY Taylor, Frances - STATE REPRESENTATIVE, DISTRICT 20 - REP                             
PSL020RMCC McClure, Angela - STATE REPRESENTATIVE, DISTRICT 20 - REP                             
PSL020RBRO Brown, James D. - STATE REPRESENTATIVE, DISTRICT 20 - REP                             
PSL023RKIR Kirkland, Mike - STATE REPRESENTATIVE, DISTRICT 23 - REP                              
PSL023RHAN Hanes, Tommy - STATE REPRESENTATIVE, DISTRICT 23 - REP                                
PSL024RLED Ledbetter, Nathaniel - STATE REPRESENTATIVE, DISTRICT 24 - REP                        
PSL024RSTO Stout, Don - STATE REPRESENTATIVE, DISTRICT 24 - REP                                  
PSL025RRIG Rigsby, Phillip K. - STATE REPRESENTATIVE, DISTRICT 25 - REP                          
PSL025RCLE Clemons, Buck - STATE REPRESENTATIVE, DISTRICT 25 - REP                               
PSL026RCOL Colvin, Brock - STATE REPRESENTATIVE, DISTRICT 26 - REP                               
PSL026RHOL Holcomb, Annette E. - STATE REPRESENTATIVE, DISTRICT 26 - REP                         
PSL026RMIT Mitchem, Todd - STATE REPRESENTATIVE, DISTRICT 26 - REP                               
PSL028RBUT Butler, Mack N - STATE REPRESENTATIVE, DISTRICT 28 - REP                              
PSL028RISB Isbell, Gil F. - STATE REPRESENTATIVE, DISTRICT 28 - REP                              
PSL029RGID Gidley, Mark A. - STATE REPRESENTATIVE, DISTRICT 29 - REP                             
PSL029RGRA Grant, Jamie W - STATE REPRESENTATIVE, DISTRICT 29 - REP                              
PSL031RSTU Stubbs, Troy B. - STATE REPRESENTATIVE, DISTRICT 31 - REP                             
PSL031RSMI Smith, Chadwick - STATE REPRESENTATIVE, DISTRICT 31 - REP                             
PSL038RWOO Wood, Debbie Hamby - STATE REPRESENTATIVE, DISTRICT 38 - REP                          
PSL038RMES Messer, Micah J. - STATE REPRESENTATIVE, DISTRICT 38 - REP                            
PSL039RSHA Shaver, Ginny - STATE REPRESENTATIVE, DISTRICT 39 - REP                               
PSL039RRHO Rhodes, Brent - STATE REPRESENTATIVE, DISTRICT 39 - REP                               
PSL040RROB Robertson, Chad - STATE REPRESENTATIVE, DISTRICT 40 - REP                             
PSL040RBOR Borrelli, Julie - STATE REPRESENTATIVE, DISTRICT 40 - REP                             
PSL040REXU Exum, Katie - STATE REPRESENTATIVE, DISTRICT 40 - REP                                 
PSL040RLES Lester, Bill - STATE REPRESENTATIVE, DISTRICT 40 - REP                                
PSL040RMCA McAdams, Bill - STATE REPRESENTATIVE, DISTRICT 40 - REP                               
PSL040RBLA Blanton, Gayla - STATE REPRESENTATIVE, DISTRICT 40 - REP                              
PSL040RWIL Williamson, Jakob - STATE REPRESENTATIVE, DISTRICT 40 - REP                           
PSL045RDUB Dubose, Susan - STATE REPRESENTATIVE, DISTRICT 45 - REP                               
PSL045RDRA Drake, Dickie - STATE REPRESENTATIVE, DISTRICT 45 - REP                               
PSL047DCOL Coleman, Christian - STATE REPRESENTATIVE, DISTRICT 47 - DEM                          
PSL047DTOO Toomey, Jim - STATE REPRESENTATIVE, DISTRICT 47 - DEM                                 
PSL048RCAR Carns, Jim - STATE REPRESENTATIVE, DISTRICT 48 - REP                                  
PSL048RWEN Wentowski, William C. - STATE REPRESENTATIVE, DISTRICT 48 - REP                       
PSL049RBED Bedsole, Russell - STATE REPRESENTATIVE, DISTRICT 49 - REP                            
PSL049RHAR Hart, Michael - STATE REPRESENTATIVE, DISTRICT 49 - REP                               
PSL052DROG Rogers, John W. Jr. - STATE REPRESENTATIVE, DISTRICT 52 - DEM                         
PSL052DMIL Millhouse, Latanya - STATE REPRESENTATIVE, DISTRICT 52 - DEM                          
PSL054DRAF Rafferty, Neil - STATE REPRESENTATIVE, DISTRICT 54 - DEM                              
PSL054DMAD Maddox, Edward - STATE REPRESENTATIVE, DISTRICT 54 - DEM                              
PSL054DBLA Blalock, Brit - STATE REPRESENTATIVE, DISTRICT 54 - DEM                               
PSL055DSCO Scott, Roderick "Rod" - STATE REPRESENTATIVE, DISTRICT 55 - DEM                       
PSL055DPLU Plump, Fred "Coach" - STATE REPRESENTATIVE, DISTRICT 55 - DEM                         
PSL055DODE Oden-Jones, Phyllis E. - STATE REPRESENTATIVE, DISTRICT 55 - DEM                      
PSL055DHEN Hendrix, Travis - STATE REPRESENTATIVE, DISTRICT 55 - DEM                             
PSL055DWOM Womack, Antwon Bernard - STATE REPRESENTATIVE, DISTRICT 55 - DEM                      
PSL056DTIL Tillman, Ontario J. - STATE REPRESENTATIVE, DISTRICT 56 - DEM                         
PSL056DHUF Huffman, Tereshia - STATE REPRESENTATIVE, DISTRICT 56 - DEM                           
PSL056DMAT Matthews, Jesse - STATE REPRESENTATIVE, DISTRICT 56 - DEM                             
PSL056DKIN King, Cleo - STATE REPRESENTATIVE, DISTRICT 56 - DEM                                  
PSL057DSEL Sellers, Patrick - STATE REPRESENTATIVE, DISTRICT 57 - DEM                            
PSL057DWIN Winston, Charles Ray III - STATE REPRESENTATIVE, DISTRICT 57 - DEM                    
PSL057DDUN Dunn, Kevin "K.D." - STATE REPRESENTATIVE, DISTRICT 57 - DEM                          
PSL060DGIV Givan, Juandalynn - STATE REPRESENTATIVE, DISTRICT 60 - DEM                           
PSL060DTAY Taylor, Nina - STATE REPRESENTATIVE, DISTRICT 60 - DEM                                
PSL061RBOL Bolton, Ron - STATE REPRESENTATIVE, DISTRICT 61 - REP                                 
PSL061RMAD Madison, Kimberly A. - STATE REPRESENTATIVE, DISTRICT 61 - REP                        
PSL064RGIV Givens, Donna - STATE REPRESENTATIVE, DISTRICT 64 - REP                               
PSL064RFER Fermo, Angelo Jacob - STATE REPRESENTATIVE, DISTRICT 64 - REP                         
PSL065REAS Easterbrook, Brett - STATE REPRESENTATIVE, DISTRICT 65 - REP                          
PSL065RCAM Campbell, Dee Ann - STATE REPRESENTATIVE, DISTRICT 65 - REP                           
PSL067DCHE Chestnut, Prince - STATE REPRESENTATIVE, DISTRICT 67 - DEM                            
PSL067DPET Pettway, Larine Irby - STATE REPRESENTATIVE, DISTRICT 67 - DEM                        
PSL072DTRA Travis, Curtis L. - STATE REPRESENTATIVE, DISTRICT 72 - DEM                           
PSL072DHOW Howard, Ralph A. - STATE REPRESENTATIVE, DISTRICT 72 - DEM                            
PSL074DENS Ensler, Phillip - STATE REPRESENTATIVE, DISTRICT 74 - DEM                             
PSL074DCAL Calhoun, Malcolm - STATE REPRESENTATIVE, DISTRICT 74 - DEM                            
PSL082DWAR Warren, Pebblin Walker - STATE REPRESENTATIVE, DISTRICT 82 - DEM                      
PSL082DJOH Johnson, Terrence Kareem - STATE REPRESENTATIVE, DISTRICT 82 - DEM                    
PSL087RSOR Sorrells, Jeff - STATE REPRESENTATIVE, DISTRICT 87 - REP                              
PSL087RJOH Johnson, Eric E. - STATE REPRESENTATIVE, DISTRICT 87 - REP                            
PSL088RSTA Starnes, Jerry - STATE REPRESENTATIVE, DISTRICT 88 - REP                              
PSL088RDIS Dismukes, Will - STATE REPRESENTATIVE, DISTRICT 88 - REP                              
PSL091RMAR Marques, Rhett - STATE REPRESENTATIVE, DISTRICT 91 - REP                              
PSL091RHOG Hogan, Les W. - STATE REPRESENTATIVE, DISTRICT 91 - REP                               
PSL092RHAM Hammett, Matthew - STATE REPRESENTATIVE, DISTRICT 92 - REP                            
PSL092RWHI White, Greg - STATE REPRESENTATIVE, DISTRICT 92 - REP                                 
PSL094RFID Fidler, Jennifer - STATE REPRESENTATIVE, DISTRICT 94 - REP                            
PSL094RFAU Faust, Joe - STATE REPRESENTATIVE, DISTRICT 94 - REP                                  
PSL095RHOL Holk-Jones, Frances - STATE REPRESENTATIVE, DISTRICT 95 - REP                         
PSL095RPUL Pulliam, Reginald C - STATE REPRESENTATIVE, DISTRICT 95 - REP                         
PSL095RLUD Ludvigsen, Michael T. Jr. - STATE REPRESENTATIVE, DISTRICT 95 - REP                  
PSL096RSIM Simpson, Matt - STATE REPRESENTATIVE, DISTRICT 96 - REP                               
PSL096RDUG Duggar, Danielle R - STATE REPRESENTATIVE, DISTRICT 96 - REP                          
PSL099DJON Jones, Sam - STATE REPRESENTATIVE, DISTRICT 99 - DEM                                  
PSL099DWRI Wright, Levi Jr. - STATE REPRESENTATIVE, DISTRICT 99 - DEM                           
PSL100RSHI Shirey, Mark - STATE REPRESENTATIVE, DISTRICT 100 - REP                               
PSL100RKUP Kupfer, Pete - STATE REPRESENTATIVE, DISTRICT 100 - REP                               
PSL100RPIG Piggott, Joe - STATE REPRESENTATIVE, DISTRICT 100 - REP                                
                                                       
                                                  
## Notes
This file allocates absentee and provisional votes based on precinct-level vote share. With the exception of Jefferson County, absentee and provisional votes are recorded at the county level. In Jefferson County, absentee and provisional votes are divided into Birmingham and Bessemer divisions. The RDH determined which precincts fell into these two sections using data from the [Jefferson County website](https://www.jccal.org/Default.asp?ID=1936&pg=Maps).

Precinct boundaries were constructed by first attempting to link 2022 primary and 2022 primary runoff election precincts to the 2022 general election precincts by name. In instances were either the names did not match or there were different number of precincts across the elections, we attempted to locate additional information about the precincts from the counties themselves. Following this step, the precinct geometries were compared against the precinct assignments present in the 2022 L2 Alabama voter file dated 7/29/2022.

Precinct boundaries primarily come from the 2022 Alabama general election shapefile (see sources above).
The following additional boundary modifications reflect changes made to the base shapefile.
Jefferson: Merge 3010 and 3015, Merge 3040 and 3045, Merge 5005, 5010 and 5015.

In the following counties there are instances where the precinct names did not match in the primary election results and the shapefile. For these counties we sourced the information from the respective counties. 
Autauga, Baldwin, Bibb, Blount, Bullock, Butler, Calhoun, Cherokee, Chilton, Choctaw, Clarke, Coffee, Colbert, Conecuh, Coosa, Covington, Crenshaw, Cullman, Dallas, DeKalb, Elmore, Etowah, Fayette, Franklin, Hale, Henry, Houston, Jefferson, Lauderdale, Lawrence, Lee, Macon, Madison, Marion, Marshall, Mobile, Monroe, Montgomery, Morgan, Pickens, Pike, St. Clair, Talladega, Tallapoosa, Tuscaloosa, Walker and Wilcox.

In order to create files where the placement of votes accurately reflects precincts split across districts, precinct geometries are split by the district geometries and the appropriate votes are assigned to the split positions of the precinct. For the purposes of disaggregation, users should use split files, but if a user is interested in analyzing all election data at once, the zip folder contains a "no_splits" file, in which precincts may contain votes for more than one district.

## Processing Steps
Visit the RDH GitHub and the processing script for this code [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection/tree/main/AL)

## Additional Notes

Files were checked against Republican and Democratic official election results files also available from the Alabama Secretary of State. Results match exactly except in the instances described below.

In the following counties, we were able to account for the vote total discrepancies between the SOS totals and RDH totals: Conecuh, Elmore, Lawrence, and Covington.

SOS totals were missing provisional ballots for the following candidates in the counties below:

Conecuh County - P22GOVDFOR, P22GOVDKEN, P22GOVDSMI, P22USSDBOY, P22USSDDEA, PCON02DHAR, PCON02DPAT, PSU23DMEL, PSU23DSAN, P22GOVRBLA
Elmore County - P22GOVFLO
Lawrence County - P22ATGRMAR, P22AUDRCOO, P22AUDRGLO, P22AUDRSOR, P22GOVRBLA, P22GOVRBUR, P22GOVRIVE, P22GOVRJAM, P22GOVRODL, P22PS1RHAM, P22PS1RODE, P22PS1RWOO, P22PS2RBEE, P22PS2RLIT, P22PS2RMCC, P22SOSRALL, P22SOSRPAC, P22SOSRZEI, P22USSRBRI, P22USSRBRO, P22USSRDUR, PSL007RROB, PSL007RYAR, PSSC5RCOO, PSSC5RJON

Precinct-level returns for Covington County had no provisional votes reported. We believe the vote total discrepancies in this county were likely due to the omission of provisional ballots in the precint-level results.

The dataset reflects the addition of the following votes as provisional.
Covington County
       - P22ATGRMAR  +19 votes
       - P22ATGRSTI +2 votes
       - P22AUDRCOO +6 votes
       - P22AUDRGLO +4 votes
       - P22AUDRSOR +9 votes
       - P22GOVRBLA +3 votes
       - P22GOVRBUR +1 votes
       - P22GOVRIVE +16 votes
       - P22GOVRJAM +3 votes
       - P22GOVRJON +1 votes
       - P22GOVRODL +2 votes
       - P22PS1RHAM +10 votes
       - P22PS1RODE +3 votes
       - P22PS1RWOO +5 votes
       - P22PS2RBEE +10 votes
       - P22PS2RLIT +1 votes
       - P22PS2RMCC +7 votes
       - P22SOSRALL +9 votes
       - P22SOSRHOR +2 votes
       - P22SOSRPAC +2 votes
       - P22SOSRZEI +9 votes
       - P22USSRBRI +10 votes
       - P22USSRBRO +7 votes
       - P22USSRDUR +7 votes
       - PSL092RHAM +12 votes
       - PSL092RWHI +13 votes
       - PSSC5RCOO +14 votes
       - PSSC5RJON +8 votes
       - PSU31RCAR +10 votes
       - PSU31RHOR +2 votes
       - PSU31RJON +14 votes 
  
In all four counties, we were able to allocate provisional votes to the precinct level using a distribution method of election day candidate perfomance.       

For the following counties and candidates, we were unable to account for vote total discrepancies between the precinct-level results and the state-level results: Autauga, Baldwin, Barbour, Blount, Crenshaw, Elmore, Escambia, Houston, Jefferson, Lauderdale, Lawrence, Madison, Marshall, Mobile, Perry, Russell, St. Clair and Walker.

In some instances, we believe the discrepancy is likely due to a data entry error or typo. Since we are unable to determine if each typo happened at the county or state level, we have chosen to leave the precinct-level results unaltered in the following cases.

Autauga County - R22PS2RMCC RDH has -1 vote
Baldwin County - P22GOVRGEO RDH has -1 vote
Barbour County - P22PS2RLIT RDH has -10 votes
Blount County - P22PS2RMCC RDH has -1 vote
Crenshaw County - P22USSDBOY RDH has +1 vote
Elmore County - P22SOSRZEI RDH has +40 votes
Escambia County - P22ATGRSTI RDH has +310 votes, we believe this is an unintentional error or typo, since SOS has 6 votes recorded for this candidate in total which would be disproportionately low.
Houston County - PBOE02RBAL RDH has -70 votes
Lauderdale County - PCON04DNEI RDH has -10 votes
Marshall County - P22GOVDSMI RDH has +1 vote
Russell County - G22A01YES RDH has +4 votes, G22A01NO RDH has +1 vote
St. Clair County - P22GOVRBUR RDH has -10 votes
Walker County- RDH has -1 vote for each of the following candidates - P22GOVDJAM, P22GOVDSMI, P22USSDBOY, P22USSDJAC, PCON04DGOR, PCON04DNEI


A full raw-from-source file including all input files is available on request from info@redistrictingdatahub.org. Please direct questions related to processing this dataset to info@redistrictingdatahub.org.