Alabama 2022 Primary Runoff Election Results and Boundaries

## RDH Date Retrieval
10/05/23

## Sources
[Alabama Secretary of State](https://www.sos.alabama.gov/alabama-votes/voter/election-data)

All county shapes were sourced from [RDH's Alabama 2022 General Election Shapefile](https://redistrictingdatahub.org/dataset/alabama-2022-general-election-precinct-level-results-and-boundaries/).
Jefferson County has modified precinct boundaries based on voter file data.
The following counties have precincts whose names in the shapefile are modified to join with the correct election results - Autauga, Baldwin, Bibb, Blount, Bullock, Butler, Calhoun, Cherokee, Chilton, Choctaw, Clarke, Coffee, Colbert, Conecuh, Coosa, Covington, Crenshaw, Cullman, Dallas, DeKalb, Elmore, Etowah, Fayette, Franklin, Hale, Henry, Houston, Jefferson, Lauderdale, Lawrence, Lee, Macon, Madison, Marion, Marshall, Mobile, Monroe, Montgomery, Morgan, Pickens, Pike, St. Clair, Talladega, Tallapoosa, Tuscaloosa, Walker and Wilcox.

## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
One example is:
G16PREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature, Public Service Commissioners and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
Office Codes Used:
AUD - State Auditor
GOV - Governor
PS# - Public Service Commissioner
SOS - Secretary Of State
USS - United States Senator
CON## - U.S. Congress
SL###  - State Legislative Lower
SU##  - State Legislative Upper

Party Codes Used:
D - Democratic
R - Republican

All fields below are present in the al_prim_runoff_22_no_splits_prec file.

## Fields:
Field Name Description
UNIQUE_ID  Unique ID for each precinct                                                      
COUNTYFP   County FIP identifier                                                            
county     County Name                                                                      
precinct   Precinct Identifier

***al_prim_runoff_22_st_prec***                                                                       
R22USSRBRI Britt, Katie - UNITED STATES SENATOR - REP                                       
R22USSRBRO Brooks, Mo - UNITED STATES SENATOR - REP                                         
R22GOVDFLO Flowers, Yolanda Rochelle - GOVERNOR - DEM                                       
R22GOVDFOR Fortier, Malika Sanders - GOVERNOR - DEM                                         
R22SOSRALL Allen, Wes - SECRETARY OF STATE - REP                                            
R22SOSRZEI Zeigler, Jim - SECRETARY OF STATE - REP                                          
R22AUDRSOR Sorrell, Andrew - STATE AUDITOR - REP                                            
R22AUDRCOO Cooke, Stan - STATE AUDITOR - REP                                                
R22PS1RODE Oden, Jeremy H. - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                       
R22PS1RWOO Woodall, Brent - PUBLIC SERVICE COMMISSION, PLACE 1 - REP                        
R22PS2RBEE Beeker, Chip - PUBLIC SERVICE COMMISSION, PLACE 2 - REP                          
R22PS2RMCC McCollum, Robert L. - PUBLIC SERVICE COMMISSION, PLACE 2 - REP

***al_prim_runoff_22_cong_prec***                   
CONG_DIST Alabama Congressional District
RCON05RSTR Strong, Dale - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP    
RCON05RWAR Wardynski, Casey - UNITED STATES REPRESENTATIVE, 5TH CONGRESSIONAL DISTRICT - REP

***al_prim_runoff_22_sldu_prec***
SLDU_DIST  Alabama State Senate District
RSU12RKEL  Kelley, Keith - STATE SENATOR, DISTRICT 12 - REP                                 
RSU12RDRA  Draper, Wendy Ghee - STATE SENATOR, DISTRICT 12 - REP                            
RSU23DSTE  Stewart, Robert L. - STATE SENATOR, DISTRICT 23 - DEM                            
RSU23DSAN  Sanders, Hank - STATE SENATOR, DISTRICT 23 - DEM

***al_prim_runoff_22_sldl_prec***                                 
SLDL_DIST Alabama State House District
RSL002RHAR Harrison, Ben - STATE REPRESENTATIVE, DISTRICT 2 - REP                           
RSL002RBLA Black, Jason Spencer - STATE REPRESENTATIVE, DISTRICT 2 - REP                    
RSL004RMOO Moore, Parker Duncan - STATE REPRESENTATIVE, DISTRICT 4 - REP                    
RSL004RJOH Johnson, Patrick - STATE REPRESENTATIVE, DISTRICT 4 - REP                        
RSL014RWAD Wadsworth, Timothy - STATE REPRESENTATIVE, DISTRICT 14 - REP               
RSL014RFRE Fredricks, Tom - STATE REPRESENTATIVE, DISTRICT 14 - REP                         
RSL020RLOM Lomax, James - STATE REPRESENTATIVE, DISTRICT 20 - REP                           
RSL020RTAY Taylor, Frances - STATE REPRESENTATIVE, DISTRICT 20 - REP                        
RSL040RROB Robertson, Chad - STATE REPRESENTATIVE, DISTRICT 40 - REP                        
RSL040RBOR Borrelli, Julie - STATE REPRESENTATIVE, DISTRICT 40 - REP                        
RSL055DPLU Plump, Fred "Coach" - STATE REPRESENTATIVE, DISTRICT 55 - DEM                    
RSL055DSCO Scott, Roderick "Rod" - STATE REPRESENTATIVE, DISTRICT 55 - DEM                  
RSL056DTIL Tillman, Ontario J. - STATE REPRESENTATIVE, DISTRICT 56 - DEM                    
RSL056DHUF Huffman, Tereshia - STATE REPRESENTATIVE, DISTRICT 56 - DEM                      
RSL057DSEL Sellers, Patrick - STATE REPRESENTATIVE, DISTRICT 57 - DEM                       
RSL057DWIN Winston, Charles Ray III - STATE REPRESENTATIVE, DISTRICT 57 - DEM               
RSL100RSHI Shirey, Mark - STATE REPRESENTATIVE, DISTRICT 100 - REP                          
RSL100RKUP Kupfer, Pete - STATE REPRESENTATIVE, DISTRICT 100 - REP 

## Notes
This file allocates absentee and provisional votes based on precinct-level vote share. With the exception of Jefferson County, absentee and provisional votes are recorded at the county level. In Jefferson County, absentee and provisional votes are divided into Birmingham and Bessemer divisions. The RDH determined which precincts fell into these two sections using data from the [Jefferson County website](https://www.jccal.org/Default.asp?ID=1936&pg=Maps).

Precinct boundaries were constructed by first attempting to link 2022 primary and 2022 primary runoff election precincts to the 2022 general election precincts by name. In instances were either the names did not match or there were different number of precincts across the elections, we attempted to locate additional information about the precincts from the counties themselves. Following this step, the precinct geometries were compared against the precinct assignments present in the 2022 L2 Alabama voter file dated 07/29/2022.

Precinct boundaries primarily come from the 2022 Alabama general election shapefile (see sources above).
The following additional boundary modifications reflect changes made to the base shapefile.
Jefferson: Merge 3040 and 3045; Merge 3070 and 3075; Merge 5005, 5010 and 5015.

In the following counties there are instances where the precinct names did not match in the primary election results and the shapefile. For these counties we sourced the information from the respective counties. 
Autauga, Baldwin, Bibb, Blount, Bullock, Butler, Calhoun, Cherokee, Chilton, Choctaw, Clarke, Coffee, Colbert, Conecuh, Coosa, Covington, Crenshaw, Cullman, Dallas, DeKalb, Elmore, Etowah, Fayette, Franklin, Hale, Henry, Houston, Jefferson, Lauderdale, Lawrence, Lee, Macon, Madison, Marion, Marshall, Mobile, Monroe, Montgomery, Morgan, Pickens, Pike, St. Clair, Talladega, Tallapoosa, Tuscaloosa, Walker and Wilcox.

In order to create files where the placement of votes accurately reflects precincts split across districts, precinct geometries are split by the district geometries and the appropriate votes are assigned to the split positions of the precinct. For the purposes of disaggregation, users should use split files, but if a user is interested in analyzing all election data at once, the zip folder contains a "no_splits" file, in which precincts may contain votes for more than one district.

## Processing Steps
Visit the RDH GitHub and the processing script for this code [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection/tree/main/AL)

## Additional Notes

Files were checked against Republican and Democratic official election results files also available from the Alabama Secretary of State. Results match exactly except in the instances described below.

For the following counties and candidates, we were unable to account for vote total discrepancies between the precinct-level results and the state-level results.
In some instances, we believe the discrepancy is likely due to a data entry error or typo. Since we are unable to determine whether the discrepancy originated at the county or state level, we have chosen to leave the precinct-level results unaltered in the following cases.
1. Autauga - RDH has -1 vote
         - R22PS2RMCC
2. Jefferson - RDH has -4 votes
         - RSL055DPLU
         - RSL055DSCO, 
3. Lawrence - RDH has -3 votes
         - R22SOSRALL
4. Madison - RDH has -1 vote
         - RSL020RLOM
5. Mobile - RDH has +1 vote for the following candidates
        - R22AUDRCOO
        - R22PS1RWOO
        - R22PS2RBEE
        - R22SOSRALL
        - R22USSRBRO
6. Perry - RDH has +1 vote for the following candidates
        - R22PS2RBEE
        - R22PS2RMCC


A full raw-from-source file including all input files is available on request from info@redistrictingdatahub.org. Please direct questions related to processing this dataset to info@redistrictingdatahub.org.