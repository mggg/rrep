L2 Voter File 2022 Elections Turnout Statistics for AL, aggregated to the 2020 Census Block level 

## Redistricting Data Hub (RDH) Retrieval Date
4/3/2023

## Sources
The Redistricting Data Hub purchased this Voter File from L2, a national Voter File vendor: https://l2-data.com/

## Fields
The fields below are from the L2 Voter File pulled by the RDH on 4/3/2023. 
L2 retrieved this voter file data from the state on 1/18/2023.
To see more detailed field descriptions, please view the attached data dictionary provided by L2. 
All fields are for individuals who are registered on the L2 Voter File as of the date of retrieval. The RDH did not have access to legacy or snapshot voter files. 
Field Name                                   		Description
geoid20                                      		15-character GEOID corresponding to 2020 Census Blocks, based on L2 geo-referencing of individual voter addresses
total_reg                                    		Count of total registered voters in the County, as geo-referenced by RDH from L2 voter file dated above
age_18_19                                    		Count of voters between the age of 18 and 19 in the Census Block
age_20_24                                    		Count of voters between the age of 20 and 24 in the Census Block
age_25_29                                    		Count of voters between the age of 25 and 29 in the Census Block
age_30_34                                    		Count of voters between the age of 30 and 34 in the Census Block
age_35_44                                    		Count of voters between the age of 35 and 44 in the Census Block
age_45_54                                    		Count of voters between the age of 45 and 54 in the Census Block
age_55_64                                    		Count of voters between the age of 55 and 64 in the Census Block
age_65_74                                    		Count of voters between the age of 65 and 74 in the Census Block
age_75_84                                    		Count of voters between the age of 75 and 84 in the Census Block
age_85over                                   		Count of voters over the age of 85 in the Census Block
voters_gender_m                              		Count of male voters
voters_gender_f                              		Count of female voters
voters_gender_unknown                        		Count of voters with unknown or other gender
party_rep                                    		Count of voters registered with the following party on the L2 Voter File: Republican *
party_dem                                    		Count of voters registered with the following party on the L2 Voter File: Democratic *
party_npp                                    		Count of voters registered with the following party on the L2 Voter File: Non-Partisan *
party_oth                                    		Count of voters registered with another party, not listed above, on the L2 Voter File
party_unk                                    		Count of voters with unknown (null) party affiliation on the L2 Voter File
eth1_eur                                     		Count of voters in the following broad ethnicity category, defined by L2: European
eth1_hisp                                    		Count of voters in the following broad ethnicity category, defined by L2: Hispanic and Portuguese
eth1_aa                                      		Count of voters in the following broad ethnicity category, defined by L2: Likely African-American
eth1_esa                                     		Count of voters in the following broad ethnicity category, defined by L2: East and South Asian
eth1_oth                                     		Count of voters in the following broad ethnicity category, defined by L2: Other
eth1_unk                                     		Count of voters with unknown (null) broad ethnicity category
eth2_euro                                    		Count of voters in the following narrow ethnicity category, defined by L2: Summed European narrow ethnicities (see notes for what is included) **
eth2_99                                      		Count of voters in the following narrow ethnicity category, defined by L2: African or Af-Am Self Reported **
eth2_64                                      		Count of voters in the following narrow ethnicity category, defined by L2: Hispanic **
eth2_93                                      		Count of voters in the following narrow ethnicity category, defined by L2: Likely Af-Am (Modeled) **
eth2_81                                      		Count of voters in the following narrow ethnicity category, defined by L2: Native American **
eth2_10                                      		Count of voters in the following narrow ethnicity category, defined by L2: Chinese **
eth2_30                                      		Count of voters in the following narrow ethnicity category, defined by L2: Arab **
eth2_23                                      		Count of voters in the following narrow ethnicity category, defined by L2: Indian/Hindu **
eth2_21                                      		Count of voters in the following narrow ethnicity category, defined by L2: Vietnamese **
eth2_14                                      		Count of voters in the following narrow ethnicity category, defined by L2: Korean **
eth2_34                                      		Count of voters in the following narrow ethnicity category, defined by L2: Russian (omitting former Soviet States) **
eth2_12                                      		Count of voters in the following narrow ethnicity category, defined by L2: Japanese **
eth2_33                                      		Count of voters in the following narrow ethnicity category, defined by L2: Turkish **
eth2_32                                      		Count of voters in the following narrow ethnicity category, defined by L2: Persian **
eth2_unk                                     		Count of voters with unknown (null) narrow ethnicity category
languages_description_English                		Count of voters on the L2 Voter File known to speak the language: English
languages_description_Spanish                		Count of voters on the L2 Voter File known to speak the language: Spanish
languages_description_Vietnamese             		Count of voters on the L2 Voter File known to speak the language: Vietnamese
languages_description_Chinese                		Count of voters on the L2 Voter File known to speak the language: Chinese
languages_description_Hindi                  		Count of voters on the L2 Voter File known to speak the language: Hindi
languages_description_Korean                 		Count of voters on the L2 Voter File known to speak the language: Korean
commercialdata_estimatedhhincomeamount_avg   		Average of modeled data for estimated household income reported by L2 for individuals in the following ranges:  $1,000-$14,999/$15,000-$24,999/$25,000-$49,999/$50,000-$74,999/$75,000-$99,999/$100,000-$124,999/$125,000-$149,999/$150,000-$174,999/$175,000-$199,999/$200,000-$249,999/$250,000+
g20221108_voted_all                          		Count of voters who voted in the following election: general_2022_11_08
g20221108_reg_all                            		Count of voters registered on or before: 2022-11-08
g20221108_pct_voted_all                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08
g20221108_voted_gender_m                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Male
g20221108_reg_gender_m                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Male
g20221108_pct_voted_gender_m                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Male
g20221108_voted_gender_f                     		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Female
g20221108_reg_gender_f                       		Count of voters registered on or before: 2022-11-08, L2 Gender: Female
g20221108_pct_voted_gender_f                 		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Female
g20221108_voted_gender_unk                   		Count of voters who voted in the following election: general_2022_11_08, L2 Gender: Unknown
g20221108_reg_gender_unk                     		Count of voters registered on or before: 2022-11-08, L2 Gender: Unknown
g20221108_pct_voted_gender_unk               		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Gender: Unknown
g20221108_voted_eur                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_reg_eur                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: European
g20221108_pct_voted_eur                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: European
g20221108_voted_hisp                         		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_reg_hisp                           		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_pct_voted_hisp                     		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Hispanic and Portuguese
g20221108_voted_aa                           		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_reg_aa                             		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Likely African-American
g20221108_pct_voted_aa                       		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Likely African-American
g20221108_voted_esa                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_reg_esa                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: East and South Asian
g20221108_pct_voted_esa                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: East and South Asian
g20221108_voted_oth                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_reg_oth                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Other
g20221108_pct_voted_oth                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Other
g20221108_voted_unk                          		Count of voters who voted in the following election: general_2022_11_08, L2 Race or Ethnicity: Unknown
g20221108_reg_unk                            		Count of voters registered on or before: 2022-11-08, L2 Race or Ethnicity: Unknown
g20221108_pct_voted_unk                      		Percent of voters registered on or before 2022-11-08 and who voted in: general_2022_11_08, L2 Race or Ethnicity: Unknown
r20220920_voted_all                          		Count of voters who voted in the following election: runoff_2022_09_20
r20220920_reg_all                            		Count of voters registered on or before: 2022-09-20
r20220920_pct_voted_all                      		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20
r20220920_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_09_20, L2 Gender: Male
r20220920_reg_gender_m                       		Count of voters registered on or before: 2022-09-20, L2 Gender: Male
r20220920_pct_voted_gender_m                 		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Gender: Male
r20220920_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_09_20, L2 Gender: Female
r20220920_reg_gender_f                       		Count of voters registered on or before: 2022-09-20, L2 Gender: Female
r20220920_pct_voted_gender_f                 		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Gender: Female
r20220920_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_09_20, L2 Gender: Unknown
r20220920_reg_gender_unk                     		Count of voters registered on or before: 2022-09-20, L2 Gender: Unknown
r20220920_pct_voted_gender_unk               		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Gender: Unknown
r20220920_voted_eur                          		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: European
r20220920_reg_eur                            		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: European
r20220920_pct_voted_eur                      		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: European
r20220920_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: Hispanic and Portuguese
r20220920_reg_hisp                           		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: Hispanic and Portuguese
r20220920_pct_voted_hisp                     		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: Hispanic and Portuguese
r20220920_voted_aa                           		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: Likely African-American
r20220920_reg_aa                             		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: Likely African-American
r20220920_pct_voted_aa                       		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: Likely African-American
r20220920_voted_esa                          		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: East and South Asian
r20220920_reg_esa                            		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: East and South Asian
r20220920_pct_voted_esa                      		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: East and South Asian
r20220920_voted_oth                          		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: Other
r20220920_reg_oth                            		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: Other
r20220920_pct_voted_oth                      		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: Other
r20220920_voted_unk                          		Count of voters who voted in the following election: runoff_2022_09_20, L2 Race or Ethnicity: Unknown
r20220920_reg_unk                            		Count of voters registered on or before: 2022-09-20, L2 Race or Ethnicity: Unknown
r20220920_pct_voted_unk                      		Percent of voters registered on or before 2022-09-20 and who voted in: runoff_2022_09_20, L2 Race or Ethnicity: Unknown
s20220712_voted_all                          		Count of voters who voted in the following election: special_2022_07_12
s20220712_reg_all                            		Count of voters registered on or before: 2022-07-12
s20220712_pct_voted_all                      		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12
s20220712_voted_gender_m                     		Count of voters who voted in the following election: special_2022_07_12, L2 Gender: Male
s20220712_reg_gender_m                       		Count of voters registered on or before: 2022-07-12, L2 Gender: Male
s20220712_pct_voted_gender_m                 		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Gender: Male
s20220712_voted_gender_f                     		Count of voters who voted in the following election: special_2022_07_12, L2 Gender: Female
s20220712_reg_gender_f                       		Count of voters registered on or before: 2022-07-12, L2 Gender: Female
s20220712_pct_voted_gender_f                 		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Gender: Female
s20220712_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_07_12, L2 Gender: Unknown
s20220712_reg_gender_unk                     		Count of voters registered on or before: 2022-07-12, L2 Gender: Unknown
s20220712_pct_voted_gender_unk               		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Gender: Unknown
s20220712_voted_eur                          		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: European
s20220712_reg_eur                            		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: European
s20220712_pct_voted_eur                      		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: European
s20220712_voted_hisp                         		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: Hispanic and Portuguese
s20220712_reg_hisp                           		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: Hispanic and Portuguese
s20220712_pct_voted_hisp                     		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: Hispanic and Portuguese
s20220712_voted_aa                           		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: Likely African-American
s20220712_reg_aa                             		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: Likely African-American
s20220712_pct_voted_aa                       		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: Likely African-American
s20220712_voted_esa                          		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: East and South Asian
s20220712_reg_esa                            		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: East and South Asian
s20220712_pct_voted_esa                      		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: East and South Asian
s20220712_voted_oth                          		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: Other
s20220712_reg_oth                            		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: Other
s20220712_pct_voted_oth                      		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: Other
s20220712_voted_unk                          		Count of voters who voted in the following election: special_2022_07_12, L2 Race or Ethnicity: Unknown
s20220712_reg_unk                            		Count of voters registered on or before: 2022-07-12, L2 Race or Ethnicity: Unknown
s20220712_pct_voted_unk                      		Percent of voters registered on or before 2022-07-12 and who voted in: special_2022_07_12, L2 Race or Ethnicity: Unknown
r20220621_voted_all                          		Count of voters who voted in the following election: runoff_2022_06_21
r20220621_reg_all                            		Count of voters registered on or before: 2022-06-21
r20220621_pct_voted_all                      		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21
r20220621_voted_gender_m                     		Count of voters who voted in the following election: runoff_2022_06_21, L2 Gender: Male
r20220621_reg_gender_m                       		Count of voters registered on or before: 2022-06-21, L2 Gender: Male
r20220621_pct_voted_gender_m                 		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Gender: Male
r20220621_voted_gender_f                     		Count of voters who voted in the following election: runoff_2022_06_21, L2 Gender: Female
r20220621_reg_gender_f                       		Count of voters registered on or before: 2022-06-21, L2 Gender: Female
r20220621_pct_voted_gender_f                 		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Gender: Female
r20220621_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2022_06_21, L2 Gender: Unknown
r20220621_reg_gender_unk                     		Count of voters registered on or before: 2022-06-21, L2 Gender: Unknown
r20220621_pct_voted_gender_unk               		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Gender: Unknown
r20220621_voted_eur                          		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: European
r20220621_reg_eur                            		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: European
r20220621_pct_voted_eur                      		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: European
r20220621_voted_hisp                         		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: Hispanic and Portuguese
r20220621_reg_hisp                           		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: Hispanic and Portuguese
r20220621_pct_voted_hisp                     		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: Hispanic and Portuguese
r20220621_voted_aa                           		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: Likely African-American
r20220621_reg_aa                             		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: Likely African-American
r20220621_pct_voted_aa                       		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: Likely African-American
r20220621_voted_esa                          		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: East and South Asian
r20220621_reg_esa                            		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: East and South Asian
r20220621_pct_voted_esa                      		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: East and South Asian
r20220621_voted_oth                          		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: Other
r20220621_reg_oth                            		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: Other
r20220621_pct_voted_oth                      		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: Other
r20220621_voted_unk                          		Count of voters who voted in the following election: runoff_2022_06_21, L2 Race or Ethnicity: Unknown
r20220621_reg_unk                            		Count of voters registered on or before: 2022-06-21, L2 Race or Ethnicity: Unknown
r20220621_pct_voted_unk                      		Percent of voters registered on or before 2022-06-21 and who voted in: runoff_2022_06_21, L2 Race or Ethnicity: Unknown
s20220524_voted_all                          		Count of voters who voted in the following election: special_2022_05_24
s20220524_reg_all                            		Count of voters registered on or before: 2022-05-24
s20220524_pct_voted_all                      		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24
s20220524_voted_gender_m                     		Count of voters who voted in the following election: special_2022_05_24, L2 Gender: Male
s20220524_reg_gender_m                       		Count of voters registered on or before: 2022-05-24, L2 Gender: Male
s20220524_pct_voted_gender_m                 		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Gender: Male
s20220524_voted_gender_f                     		Count of voters who voted in the following election: special_2022_05_24, L2 Gender: Female
s20220524_reg_gender_f                       		Count of voters registered on or before: 2022-05-24, L2 Gender: Female
s20220524_pct_voted_gender_f                 		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Gender: Female
s20220524_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_05_24, L2 Gender: Unknown
s20220524_reg_gender_unk                     		Count of voters registered on or before: 2022-05-24, L2 Gender: Unknown
s20220524_pct_voted_gender_unk               		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Gender: Unknown
s20220524_voted_eur                          		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: European
s20220524_reg_eur                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: European
s20220524_pct_voted_eur                      		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: European
s20220524_voted_hisp                         		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: Hispanic and Portuguese
s20220524_reg_hisp                           		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Hispanic and Portuguese
s20220524_pct_voted_hisp                     		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: Hispanic and Portuguese
s20220524_voted_aa                           		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: Likely African-American
s20220524_reg_aa                             		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Likely African-American
s20220524_pct_voted_aa                       		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: Likely African-American
s20220524_voted_esa                          		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: East and South Asian
s20220524_reg_esa                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: East and South Asian
s20220524_pct_voted_esa                      		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: East and South Asian
s20220524_voted_oth                          		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: Other
s20220524_reg_oth                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Other
s20220524_pct_voted_oth                      		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: Other
s20220524_voted_unk                          		Count of voters who voted in the following election: special_2022_05_24, L2 Race or Ethnicity: Unknown
s20220524_reg_unk                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Unknown
s20220524_pct_voted_unk                      		Percent of voters registered on or before 2022-05-24 and who voted in: special_2022_05_24, L2 Race or Ethnicity: Unknown
p20220524_voted_all                          		Count of voters who voted in the following election: primary_2022_05_24
p20220524_reg_all                            		Count of voters registered on or before: 2022-05-24
p20220524_pct_voted_all                      		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24
p20220524_voted_gender_m                     		Count of voters who voted in the following election: primary_2022_05_24, L2 Gender: Male
p20220524_reg_gender_m                       		Count of voters registered on or before: 2022-05-24, L2 Gender: Male
p20220524_pct_voted_gender_m                 		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Gender: Male
p20220524_voted_gender_f                     		Count of voters who voted in the following election: primary_2022_05_24, L2 Gender: Female
p20220524_reg_gender_f                       		Count of voters registered on or before: 2022-05-24, L2 Gender: Female
p20220524_pct_voted_gender_f                 		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Gender: Female
p20220524_voted_gender_unk                   		Count of voters who voted in the following election: primary_2022_05_24, L2 Gender: Unknown
p20220524_reg_gender_unk                     		Count of voters registered on or before: 2022-05-24, L2 Gender: Unknown
p20220524_pct_voted_gender_unk               		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Gender: Unknown
p20220524_voted_eur                          		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: European
p20220524_reg_eur                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: European
p20220524_pct_voted_eur                      		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: European
p20220524_voted_hisp                         		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: Hispanic and Portuguese
p20220524_reg_hisp                           		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Hispanic and Portuguese
p20220524_pct_voted_hisp                     		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: Hispanic and Portuguese
p20220524_voted_aa                           		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: Likely African-American
p20220524_reg_aa                             		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Likely African-American
p20220524_pct_voted_aa                       		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: Likely African-American
p20220524_voted_esa                          		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: East and South Asian
p20220524_reg_esa                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: East and South Asian
p20220524_pct_voted_esa                      		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: East and South Asian
p20220524_voted_oth                          		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: Other
p20220524_reg_oth                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Other
p20220524_pct_voted_oth                      		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: Other
p20220524_voted_unk                          		Count of voters who voted in the following election: primary_2022_05_24, L2 Race or Ethnicity: Unknown
p20220524_reg_unk                            		Count of voters registered on or before: 2022-05-24, L2 Race or Ethnicity: Unknown
p20220524_pct_voted_unk                      		Percent of voters registered on or before 2022-05-24 and who voted in: primary_2022_05_24, L2 Race or Ethnicity: Unknown
s20220322_voted_all                          		Count of voters who voted in the following election: special_2022_03_22
s20220322_reg_all                            		Count of voters registered on or before: 2022-03-22
s20220322_pct_voted_all                      		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22
s20220322_voted_gender_m                     		Count of voters who voted in the following election: special_2022_03_22, L2 Gender: Male
s20220322_reg_gender_m                       		Count of voters registered on or before: 2022-03-22, L2 Gender: Male
s20220322_pct_voted_gender_m                 		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Gender: Male
s20220322_voted_gender_f                     		Count of voters who voted in the following election: special_2022_03_22, L2 Gender: Female
s20220322_reg_gender_f                       		Count of voters registered on or before: 2022-03-22, L2 Gender: Female
s20220322_pct_voted_gender_f                 		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Gender: Female
s20220322_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_03_22, L2 Gender: Unknown
s20220322_reg_gender_unk                     		Count of voters registered on or before: 2022-03-22, L2 Gender: Unknown
s20220322_pct_voted_gender_unk               		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Gender: Unknown
s20220322_voted_eur                          		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: European
s20220322_reg_eur                            		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: European
s20220322_pct_voted_eur                      		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: European
s20220322_voted_hisp                         		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: Hispanic and Portuguese
s20220322_reg_hisp                           		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: Hispanic and Portuguese
s20220322_pct_voted_hisp                     		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: Hispanic and Portuguese
s20220322_voted_aa                           		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: Likely African-American
s20220322_reg_aa                             		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: Likely African-American
s20220322_pct_voted_aa                       		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: Likely African-American
s20220322_voted_esa                          		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: East and South Asian
s20220322_reg_esa                            		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: East and South Asian
s20220322_pct_voted_esa                      		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: East and South Asian
s20220322_voted_oth                          		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: Other
s20220322_reg_oth                            		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: Other
s20220322_pct_voted_oth                      		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: Other
s20220322_voted_unk                          		Count of voters who voted in the following election: special_2022_03_22, L2 Race or Ethnicity: Unknown
s20220322_reg_unk                            		Count of voters registered on or before: 2022-03-22, L2 Race or Ethnicity: Unknown
s20220322_pct_voted_unk                      		Percent of voters registered on or before 2022-03-22 and who voted in: special_2022_03_22, L2 Race or Ethnicity: Unknown
s20220111_voted_all                          		Count of voters who voted in the following election: special_2022_01_11
s20220111_reg_all                            		Count of voters registered on or before: 2022-01-11
s20220111_pct_voted_all                      		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11
s20220111_voted_gender_m                     		Count of voters who voted in the following election: special_2022_01_11, L2 Gender: Male
s20220111_reg_gender_m                       		Count of voters registered on or before: 2022-01-11, L2 Gender: Male
s20220111_pct_voted_gender_m                 		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Gender: Male
s20220111_voted_gender_f                     		Count of voters who voted in the following election: special_2022_01_11, L2 Gender: Female
s20220111_reg_gender_f                       		Count of voters registered on or before: 2022-01-11, L2 Gender: Female
s20220111_pct_voted_gender_f                 		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Gender: Female
s20220111_voted_gender_unk                   		Count of voters who voted in the following election: special_2022_01_11, L2 Gender: Unknown
s20220111_reg_gender_unk                     		Count of voters registered on or before: 2022-01-11, L2 Gender: Unknown
s20220111_pct_voted_gender_unk               		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Gender: Unknown
s20220111_voted_eur                          		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: European
s20220111_reg_eur                            		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: European
s20220111_pct_voted_eur                      		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: European
s20220111_voted_hisp                         		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: Hispanic and Portuguese
s20220111_reg_hisp                           		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: Hispanic and Portuguese
s20220111_pct_voted_hisp                     		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: Hispanic and Portuguese
s20220111_voted_aa                           		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: Likely African-American
s20220111_reg_aa                             		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: Likely African-American
s20220111_pct_voted_aa                       		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: Likely African-American
s20220111_voted_esa                          		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: East and South Asian
s20220111_reg_esa                            		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: East and South Asian
s20220111_pct_voted_esa                      		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: East and South Asian
s20220111_voted_oth                          		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: Other
s20220111_reg_oth                            		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: Other
s20220111_pct_voted_oth                      		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: Other
s20220111_voted_unk                          		Count of voters who voted in the following election: special_2022_01_11, L2 Race or Ethnicity: Unknown
s20220111_reg_unk                            		Count of voters registered on or before: 2022-01-11, L2 Race or Ethnicity: Unknown
s20220111_pct_voted_unk                      		Percent of voters registered on or before 2022-01-11 and who voted in: special_2022_01_11, L2 Race or Ethnicity: Unknown
s20211005_voted_all                          		Count of voters who voted in the following election: special_2021_10_05
s20211005_reg_all                            		Count of voters registered on or before: 2021-10-05
s20211005_pct_voted_all                      		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05
s20211005_voted_gender_m                     		Count of voters who voted in the following election: special_2021_10_05, L2 Gender: Male
s20211005_reg_gender_m                       		Count of voters registered on or before: 2021-10-05, L2 Gender: Male
s20211005_pct_voted_gender_m                 		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Gender: Male
s20211005_voted_gender_f                     		Count of voters who voted in the following election: special_2021_10_05, L2 Gender: Female
s20211005_reg_gender_f                       		Count of voters registered on or before: 2021-10-05, L2 Gender: Female
s20211005_pct_voted_gender_f                 		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Gender: Female
s20211005_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_10_05, L2 Gender: Unknown
s20211005_reg_gender_unk                     		Count of voters registered on or before: 2021-10-05, L2 Gender: Unknown
s20211005_pct_voted_gender_unk               		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Gender: Unknown
s20211005_voted_eur                          		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: European
s20211005_reg_eur                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: European
s20211005_pct_voted_eur                      		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: European
s20211005_voted_hisp                         		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: Hispanic and Portuguese
s20211005_reg_hisp                           		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Hispanic and Portuguese
s20211005_pct_voted_hisp                     		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: Hispanic and Portuguese
s20211005_voted_aa                           		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: Likely African-American
s20211005_reg_aa                             		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Likely African-American
s20211005_pct_voted_aa                       		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: Likely African-American
s20211005_voted_esa                          		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: East and South Asian
s20211005_reg_esa                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: East and South Asian
s20211005_pct_voted_esa                      		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: East and South Asian
s20211005_voted_oth                          		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: Other
s20211005_reg_oth                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Other
s20211005_pct_voted_oth                      		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: Other
s20211005_voted_unk                          		Count of voters who voted in the following election: special_2021_10_05, L2 Race or Ethnicity: Unknown
s20211005_reg_unk                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Unknown
s20211005_pct_voted_unk                      		Percent of voters registered on or before 2021-10-05 and who voted in: special_2021_10_05, L2 Race or Ethnicity: Unknown
r20211005_voted_all                          		Count of voters who voted in the following election: runoff_2021_10_05
r20211005_reg_all                            		Count of voters registered on or before: 2021-10-05
r20211005_pct_voted_all                      		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05
r20211005_voted_gender_m                     		Count of voters who voted in the following election: runoff_2021_10_05, L2 Gender: Male
r20211005_reg_gender_m                       		Count of voters registered on or before: 2021-10-05, L2 Gender: Male
r20211005_pct_voted_gender_m                 		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Gender: Male
r20211005_voted_gender_f                     		Count of voters who voted in the following election: runoff_2021_10_05, L2 Gender: Female
r20211005_reg_gender_f                       		Count of voters registered on or before: 2021-10-05, L2 Gender: Female
r20211005_pct_voted_gender_f                 		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Gender: Female
r20211005_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2021_10_05, L2 Gender: Unknown
r20211005_reg_gender_unk                     		Count of voters registered on or before: 2021-10-05, L2 Gender: Unknown
r20211005_pct_voted_gender_unk               		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Gender: Unknown
r20211005_voted_eur                          		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: European
r20211005_reg_eur                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: European
r20211005_pct_voted_eur                      		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: European
r20211005_voted_hisp                         		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: Hispanic and Portuguese
r20211005_reg_hisp                           		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Hispanic and Portuguese
r20211005_pct_voted_hisp                     		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: Hispanic and Portuguese
r20211005_voted_aa                           		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: Likely African-American
r20211005_reg_aa                             		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Likely African-American
r20211005_pct_voted_aa                       		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: Likely African-American
r20211005_voted_esa                          		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: East and South Asian
r20211005_reg_esa                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: East and South Asian
r20211005_pct_voted_esa                      		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: East and South Asian
r20211005_voted_oth                          		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: Other
r20211005_reg_oth                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Other
r20211005_pct_voted_oth                      		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: Other
r20211005_voted_unk                          		Count of voters who voted in the following election: runoff_2021_10_05, L2 Race or Ethnicity: Unknown
r20211005_reg_unk                            		Count of voters registered on or before: 2021-10-05, L2 Race or Ethnicity: Unknown
r20211005_pct_voted_unk                      		Percent of voters registered on or before 2021-10-05 and who voted in: runoff_2021_10_05, L2 Race or Ethnicity: Unknown
r20210914_voted_all                          		Count of voters who voted in the following election: runoff_2021_09_14
r20210914_reg_all                            		Count of voters registered on or before: 2021-09-14
r20210914_pct_voted_all                      		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14
r20210914_voted_gender_m                     		Count of voters who voted in the following election: runoff_2021_09_14, L2 Gender: Male
r20210914_reg_gender_m                       		Count of voters registered on or before: 2021-09-14, L2 Gender: Male
r20210914_pct_voted_gender_m                 		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Gender: Male
r20210914_voted_gender_f                     		Count of voters who voted in the following election: runoff_2021_09_14, L2 Gender: Female
r20210914_reg_gender_f                       		Count of voters registered on or before: 2021-09-14, L2 Gender: Female
r20210914_pct_voted_gender_f                 		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Gender: Female
r20210914_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2021_09_14, L2 Gender: Unknown
r20210914_reg_gender_unk                     		Count of voters registered on or before: 2021-09-14, L2 Gender: Unknown
r20210914_pct_voted_gender_unk               		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Gender: Unknown
r20210914_voted_eur                          		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: European
r20210914_reg_eur                            		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: European
r20210914_pct_voted_eur                      		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: European
r20210914_voted_hisp                         		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: Hispanic and Portuguese
r20210914_reg_hisp                           		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: Hispanic and Portuguese
r20210914_pct_voted_hisp                     		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: Hispanic and Portuguese
r20210914_voted_aa                           		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: Likely African-American
r20210914_reg_aa                             		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: Likely African-American
r20210914_pct_voted_aa                       		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: Likely African-American
r20210914_voted_esa                          		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: East and South Asian
r20210914_reg_esa                            		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: East and South Asian
r20210914_pct_voted_esa                      		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: East and South Asian
r20210914_voted_oth                          		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: Other
r20210914_reg_oth                            		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: Other
r20210914_pct_voted_oth                      		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: Other
r20210914_voted_unk                          		Count of voters who voted in the following election: runoff_2021_09_14, L2 Race or Ethnicity: Unknown
r20210914_reg_unk                            		Count of voters registered on or before: 2021-09-14, L2 Race or Ethnicity: Unknown
r20210914_pct_voted_unk                      		Percent of voters registered on or before 2021-09-14 and who voted in: runoff_2021_09_14, L2 Race or Ethnicity: Unknown
s20210907_voted_all                          		Count of voters who voted in the following election: special_2021_09_07
s20210907_reg_all                            		Count of voters registered on or before: 2021-09-07
s20210907_pct_voted_all                      		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07
s20210907_voted_gender_m                     		Count of voters who voted in the following election: special_2021_09_07, L2 Gender: Male
s20210907_reg_gender_m                       		Count of voters registered on or before: 2021-09-07, L2 Gender: Male
s20210907_pct_voted_gender_m                 		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Gender: Male
s20210907_voted_gender_f                     		Count of voters who voted in the following election: special_2021_09_07, L2 Gender: Female
s20210907_reg_gender_f                       		Count of voters registered on or before: 2021-09-07, L2 Gender: Female
s20210907_pct_voted_gender_f                 		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Gender: Female
s20210907_voted_gender_unk                   		Count of voters who voted in the following election: special_2021_09_07, L2 Gender: Unknown
s20210907_reg_gender_unk                     		Count of voters registered on or before: 2021-09-07, L2 Gender: Unknown
s20210907_pct_voted_gender_unk               		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Gender: Unknown
s20210907_voted_eur                          		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: European
s20210907_reg_eur                            		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: European
s20210907_pct_voted_eur                      		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: European
s20210907_voted_hisp                         		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: Hispanic and Portuguese
s20210907_reg_hisp                           		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: Hispanic and Portuguese
s20210907_pct_voted_hisp                     		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: Hispanic and Portuguese
s20210907_voted_aa                           		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: Likely African-American
s20210907_reg_aa                             		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: Likely African-American
s20210907_pct_voted_aa                       		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: Likely African-American
s20210907_voted_esa                          		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: East and South Asian
s20210907_reg_esa                            		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: East and South Asian
s20210907_pct_voted_esa                      		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: East and South Asian
s20210907_voted_oth                          		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: Other
s20210907_reg_oth                            		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: Other
s20210907_pct_voted_oth                      		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: Other
s20210907_voted_unk                          		Count of voters who voted in the following election: special_2021_09_07, L2 Race or Ethnicity: Unknown
s20210907_reg_unk                            		Count of voters registered on or before: 2021-09-07, L2 Race or Ethnicity: Unknown
s20210907_pct_voted_unk                      		Percent of voters registered on or before 2021-09-07 and who voted in: special_2021_09_07, L2 Race or Ethnicity: Unknown
r20210413_voted_all                          		Count of voters who voted in the following election: runoff_2021_04_13
r20210413_reg_all                            		Count of voters registered on or before: 2021-04-13
r20210413_pct_voted_all                      		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13
r20210413_voted_gender_m                     		Count of voters who voted in the following election: runoff_2021_04_13, L2 Gender: Male
r20210413_reg_gender_m                       		Count of voters registered on or before: 2021-04-13, L2 Gender: Male
r20210413_pct_voted_gender_m                 		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Gender: Male
r20210413_voted_gender_f                     		Count of voters who voted in the following election: runoff_2021_04_13, L2 Gender: Female
r20210413_reg_gender_f                       		Count of voters registered on or before: 2021-04-13, L2 Gender: Female
r20210413_pct_voted_gender_f                 		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Gender: Female
r20210413_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2021_04_13, L2 Gender: Unknown
r20210413_reg_gender_unk                     		Count of voters registered on or before: 2021-04-13, L2 Gender: Unknown
r20210413_pct_voted_gender_unk               		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Gender: Unknown
r20210413_voted_eur                          		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: European
r20210413_reg_eur                            		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: European
r20210413_pct_voted_eur                      		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: European
r20210413_voted_hisp                         		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: Hispanic and Portuguese
r20210413_reg_hisp                           		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: Hispanic and Portuguese
r20210413_pct_voted_hisp                     		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: Hispanic and Portuguese
r20210413_voted_aa                           		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: Likely African-American
r20210413_reg_aa                             		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: Likely African-American
r20210413_pct_voted_aa                       		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: Likely African-American
r20210413_voted_esa                          		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: East and South Asian
r20210413_reg_esa                            		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: East and South Asian
r20210413_pct_voted_esa                      		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: East and South Asian
r20210413_voted_oth                          		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: Other
r20210413_reg_oth                            		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: Other
r20210413_pct_voted_oth                      		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: Other
r20210413_voted_unk                          		Count of voters who voted in the following election: runoff_2021_04_13, L2 Race or Ethnicity: Unknown
r20210413_reg_unk                            		Count of voters registered on or before: 2021-04-13, L2 Race or Ethnicity: Unknown
r20210413_pct_voted_unk                      		Percent of voters registered on or before 2021-04-13 and who voted in: runoff_2021_04_13, L2 Race or Ethnicity: Unknown
g20201103_voted_all                          		Count of voters who voted in the following election: general_2020_11_03
g20201103_reg_all                            		Count of voters registered on or before: 2020-11-03
g20201103_pct_voted_all                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03
g20201103_voted_gender_m                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Male
g20201103_reg_gender_m                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Male
g20201103_pct_voted_gender_m                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Male
g20201103_voted_gender_f                     		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Female
g20201103_reg_gender_f                       		Count of voters registered on or before: 2020-11-03, L2 Gender: Female
g20201103_pct_voted_gender_f                 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Female
g20201103_voted_gender_unk                   		Count of voters who voted in the following election: general_2020_11_03, L2 Gender: Unknown
g20201103_reg_gender_unk                     		Count of voters registered on or before: 2020-11-03, L2 Gender: Unknown
g20201103_pct_voted_gender_unk               		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Gender: Unknown
g20201103_voted_eur                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_reg_eur                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: European
g20201103_pct_voted_eur                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_voted_hisp                         		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_reg_hisp                           		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_pct_voted_hisp                     		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_voted_aa                           		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_reg_aa                             		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Likely African-American
g20201103_pct_voted_aa                       		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_voted_esa                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_reg_esa                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: East and South Asian
g20201103_pct_voted_esa                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_voted_oth                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_reg_oth                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Other
g20201103_pct_voted_oth                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_voted_unk                          		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Unknown
g20201103_reg_unk                            		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Unknown
g20201103_pct_voted_unk                      		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Unknown
r20201006_voted_all                          		Count of voters who voted in the following election: runoff_2020_10_06
r20201006_reg_all                            		Count of voters registered on or before: 2020-10-06
r20201006_pct_voted_all                      		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06
r20201006_voted_gender_m                     		Count of voters who voted in the following election: runoff_2020_10_06, L2 Gender: Male
r20201006_reg_gender_m                       		Count of voters registered on or before: 2020-10-06, L2 Gender: Male
r20201006_pct_voted_gender_m                 		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Gender: Male
r20201006_voted_gender_f                     		Count of voters who voted in the following election: runoff_2020_10_06, L2 Gender: Female
r20201006_reg_gender_f                       		Count of voters registered on or before: 2020-10-06, L2 Gender: Female
r20201006_pct_voted_gender_f                 		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Gender: Female
r20201006_voted_gender_unk                   		Count of voters who voted in the following election: runoff_2020_10_06, L2 Gender: Unknown
r20201006_reg_gender_unk                     		Count of voters registered on or before: 2020-10-06, L2 Gender: Unknown
r20201006_pct_voted_gender_unk               		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Gender: Unknown
r20201006_voted_eur                          		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: European
r20201006_reg_eur                            		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: European
r20201006_pct_voted_eur                      		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: European
r20201006_voted_hisp                         		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: Hispanic and Portuguese
r20201006_reg_hisp                           		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: Hispanic and Portuguese
r20201006_pct_voted_hisp                     		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: Hispanic and Portuguese
r20201006_voted_aa                           		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: Likely African-American
r20201006_reg_aa                             		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: Likely African-American
r20201006_pct_voted_aa                       		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: Likely African-American
r20201006_voted_esa                          		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: East and South Asian
r20201006_reg_esa                            		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: East and South Asian
r20201006_pct_voted_esa                      		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: East and South Asian
r20201006_voted_oth                          		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: Other
r20201006_reg_oth                            		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: Other
r20201006_pct_voted_oth                      		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: Other
r20201006_voted_unk                          		Count of voters who voted in the following election: runoff_2020_10_06, L2 Race or Ethnicity: Unknown
r20201006_reg_unk                            		Count of voters registered on or before: 2020-10-06, L2 Race or Ethnicity: Unknown
r20201006_pct_voted_unk                      		Percent of voters registered on or before 2020-10-06 and who voted in: runoff_2020_10_06, L2 Race or Ethnicity: Unknown
pp20200303_voted_all                         		Count of voters who voted in the following election: presidential_primary_2020_03_03
pp20200303_reg_all                           		Count of voters registered on or before: 2020-03-03
pp20200303_pct_voted_all                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03
pp20200303_voted_gender_m                    		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Male
pp20200303_reg_gender_m                      		Count of voters registered on or before: 2020-03-03, L2 Gender: Male
pp20200303_pct_voted_gender_m                		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Male
pp20200303_voted_gender_f                    		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Female
pp20200303_reg_gender_f                      		Count of voters registered on or before: 2020-03-03, L2 Gender: Female
pp20200303_pct_voted_gender_f                		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Female
pp20200303_voted_gender_unk                  		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Gender: Unknown
pp20200303_reg_gender_unk                    		Count of voters registered on or before: 2020-03-03, L2 Gender: Unknown
pp20200303_pct_voted_gender_unk              		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Gender: Unknown
pp20200303_voted_eur                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: European
pp20200303_reg_eur                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: European
pp20200303_pct_voted_eur                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: European
pp20200303_voted_hisp                        		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_reg_hisp                          		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_pct_voted_hisp                    		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200303_voted_aa                          		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
pp20200303_reg_aa                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Likely African-American
pp20200303_pct_voted_aa                      		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
pp20200303_voted_esa                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
pp20200303_reg_esa                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: East and South Asian
pp20200303_pct_voted_esa                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
pp20200303_voted_oth                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Other
pp20200303_reg_oth                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Other
pp20200303_pct_voted_oth                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Other
pp20200303_voted_unk                         		Count of voters who voted in the following election: presidential_primary_2020_03_03, L2 Race or Ethnicity: Unknown
pp20200303_reg_unk                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Unknown
pp20200303_pct_voted_unk                     		Percent of voters registered on or before 2020-03-03 and who voted in: presidential_primary_2020_03_03, L2 Race or Ethnicity: Unknown
p20200303_voted_all                          		Count of voters who voted in the following election: primary_2020_03_03
p20200303_reg_all                            		Count of voters registered on or before: 2020-03-03
p20200303_pct_voted_all                      		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03
p20200303_voted_gender_m                     		Count of voters who voted in the following election: primary_2020_03_03, L2 Gender: Male
p20200303_reg_gender_m                       		Count of voters registered on or before: 2020-03-03, L2 Gender: Male
p20200303_pct_voted_gender_m                 		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Gender: Male
p20200303_voted_gender_f                     		Count of voters who voted in the following election: primary_2020_03_03, L2 Gender: Female
p20200303_reg_gender_f                       		Count of voters registered on or before: 2020-03-03, L2 Gender: Female
p20200303_pct_voted_gender_f                 		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Gender: Female
p20200303_voted_gender_unk                   		Count of voters who voted in the following election: primary_2020_03_03, L2 Gender: Unknown
p20200303_reg_gender_unk                     		Count of voters registered on or before: 2020-03-03, L2 Gender: Unknown
p20200303_pct_voted_gender_unk               		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Gender: Unknown
p20200303_voted_eur                          		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: European
p20200303_reg_eur                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: European
p20200303_pct_voted_eur                      		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: European
p20200303_voted_hisp                         		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
p20200303_reg_hisp                           		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Hispanic and Portuguese
p20200303_pct_voted_hisp                     		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: Hispanic and Portuguese
p20200303_voted_aa                           		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
p20200303_reg_aa                             		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Likely African-American
p20200303_pct_voted_aa                       		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: Likely African-American
p20200303_voted_esa                          		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
p20200303_reg_esa                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: East and South Asian
p20200303_pct_voted_esa                      		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: East and South Asian
p20200303_voted_oth                          		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: Other
p20200303_reg_oth                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Other
p20200303_pct_voted_oth                      		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: Other
p20200303_voted_unk                          		Count of voters who voted in the following election: primary_2020_03_03, L2 Race or Ethnicity: Unknown
p20200303_reg_unk                            		Count of voters registered on or before: 2020-03-03, L2 Race or Ethnicity: Unknown
p20200303_pct_voted_unk                      		Percent of voters registered on or before 2020-03-03 and who voted in: primary_2020_03_03, L2 Race or Ethnicity: Unknown

## Processing 
L2 provides individual address data for every voter on their voter file. 
Many of the voters contain latitude/longitude data. The RDH assigns 2020 Census blocks to voters containing latitude/longitude data by spatially joining the points with Census block files. 
Voters that are assigned to a block in a county that does not match their county on the voter file are removed as a quality control check. 
The individual data is aggregated to the block-level by grouping by block assignments. Individuals who could not be assigned a Census block because of missing latitude/longitude were assigned “NO ASSIGNMENT - [county fips code assignment]" and therefore reported as county aggregates in the geoid20 column.

## Additional Notes 
The fields in this file correspond to those voters registered to vote at their residence as of the date mentioned above. 
The vote history fields are tied to individual voters, then aggregated up - not tied to blocks as a whole, and as such represent whether or not voters in the block as of the L2 voter file date above voted *anywhere*, not necessarily specifically in that block. 
As such, this information can be used to approximate how the demographic in the block voted historically, but cannot be used to track how individuals in that block voted at the time of previous elections. For snapshots from previous voter files, please reference previous voter files hosted by the RDH. 

The RDH cannot certify the accuracy of any of the information contained within this file.

* RDH is providing aggregates of the top 8 parties in the state. 
** For the narrow ethnicity categories, RDH is providing an aggregate of all ethnicities that have more than 
1000 individuals state-wide. L2 ethnicity categories use modeling techniques to infer an individual's ethnicity.
Please see the attached PDF for  more information about L2's ethnicity fields. 


Please contact info@redistrictingdatahub.org for more information. 